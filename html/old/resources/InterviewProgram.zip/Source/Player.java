package interviewprogram;

/**
 *
 * @author Nicholas
 */
public class Player {
    private final String name;
    private int boardLocation, money;
    private final int startingMoney;
    
    //Player Constructor
    Player(String name, int money){
        this.name=name;
        boardLocation=1;
        this.startingMoney=money;
        this.money=money;
    }
    
    /**
     * Returns The Player Name
     * @return String name
     */
    public String getName(){
        return name;
    }
    
    /**
     * Returns The Players Current Money
     * @return int money
     */
    public int getMoney(){
        return money;
    }
    
    /**
     * Set The Players Money
     * @param money
     */
    public void setMoney(int money){
        this.money=money;
    }
    
    /**
     * Get The Players Board Location
     * @return boardLocation
     */
    public int getBoardLocation(){
        return boardLocation;
    }
    
    /**
     * Set The Players Board Location
     * @param newLocation
     */
    public void setBoardLocation(int newLocation){
        boardLocation=newLocation;
    }
    
    /**
     * Reset the Players Board Position and Money
     */
    public void reset(){
        boardLocation=1;
        money=startingMoney;
    }
}
