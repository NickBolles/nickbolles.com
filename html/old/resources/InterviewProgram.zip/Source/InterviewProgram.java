package interviewprogram;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Nicholas Bolles
 */
public class InterviewProgram {

    public static void main(String[] args) {
        final ArrayList<square> board=new ArrayList(){{
            add(new square("Go","penalty", 0));
            add(new square("Mediterranean Avenue", "property", 60));
            add(new square("Community Chest", "penalty", 0));
            add(new square("Baltic Avenue", "property", 60));
            add(new square("Income Tax" ,"penalty", 200));
            add(new square("Reading Railroad" ,"property", 200));
            add(new square("Oriental Avenue", "property",100));
            add(new square("Chance", "penalty",0));
            add(new square("Vermont Avenue","property",100));
            add(new square("Connecticut Avenue" ,"property",120));
            add(new square("Jail Visit","penalty", 50));
            add(new square("St. Charles Place","property",140));
            add(new square("Electric Company","property",150));
            add(new square("States Avenue","property", 140));
            add(new square("Virginia Avenue","property", 160));
            add(new square("Pennsylvania Railroad","property", 200));
            add(new square("St. James Place","property", 200));
            add(new square("Community Chest", "penalty", 0));
            add(new square("Tennessee Avenue","property", 180));
            add(new square("New York Avenue","property", 200));
            add(new square("Free Parking","penalty", 0));
            add(new square("Kentucky Avenue","property", 220));
            add(new square("Chance", "penalty",0));
            add(new square("Indiana Avenue","property", 220));
            add(new square("Illinois Avenue","property", 240));
            add(new square("B. & O. Railroad","property", 200));
            add(new square("Atlantic Avenue","property", 260));
            add(new square("Ventnor Avenue","property", 260));
            add(new square("Water Works","property", 150));
            add(new square("Marvin Gardens","property", 280));
            add(new square("Police Bribe","penalty", 50));
            add(new square("Pacific Avenue","property", 300));
            add(new square("North Carolina Avenue","property", 300));
            add(new square("Community Chest", "penalty", 0));
            add(new square("Pennsylvania Avenue","property", 300));
            add(new square("Short Line","property", 320));
            add(new square("Chance", "penalty",0));
            add(new square("Park Place","property", 350));
            add(new square("Luxury Tax","penalty", 75));
            add(new square("Boardwalk","property", 400));
        }};
        boolean quit=false, play;
        
        
        
        System.out.println("Real-Estate Board Game Simulator                   By: Nicholas Bolles");
        System.out.println("======================================================================");
        while(quit==false){//Outer Loop To keep program running if desired
            
            //Declare all variables and Set them to default Values.
            boolean inputValid; 
            int numPlayers, numToSimulate, dollarAmmount;
            double totalNumPropertyBought=0, totalNumRolls=0, totalIndianaAvePurchased=0, avgNumRolls,avgNumPropertiesBaught, percentIndianaAvePurchased;
            ArrayList<Player> players=new ArrayList();
            Player currentPlayer;
            square currentSquare;
            Scanner scanner=new Scanner(System.in);
            
            
            //Get Number of Players
            System.out.println("Please Enter The Number of Players ");
            numPlayers = promptForInt();

            //Get Ammount of Starting Money
            System.out.println("Please Enter The Starting Dollar Ammount");
            dollarAmmount= promptForInt();
            
            //Create and add Player to Players ArrayList
            for(int i=0;i<numPlayers;i++){
                players.add(new Player("Player " + i, dollarAmmount));
            }
            
            //Get number of games to simulate
            System.out.println("Please Enter The Number Games to Simulate");
            numToSimulate=promptForInt();

            //Start of the simulation           
            System.out.println("=========================================================================");
            for(int i=0;i<numToSimulate;i++){ 
                
                //Call reset method for every Player to reset their game position and money to the starting value
                for(int p=0;p<numPlayers;p++){
                    players.get(p).reset();
                }
                
                //Redeclare and reset Variables
                int playerIndex, die1, die2, rollTotal, numTurns=0;
                play=true;
                
                               
                while (play==true){  //Start of the Game Loop
                    

                    //Determine which players turn it is by Modulus counter(numTurns) and numPlayers
                    playerIndex=numTurns%numPlayers;

                    //Get the Current Player for easier functions
                    currentPlayer=players.get(playerIndex);
                    
                    //Roll both dice
                    die1 = (int) ((Math.random()*6) + 1);
                    die2 = (int) ((Math.random()*6) + 1);
                    
                    //Add rolls together
                    rollTotal=die1+die2;
                    
                    //Calculate new position on the board
                    int newPosition= rollTotal + currentPlayer.getBoardLocation();

                    //Check to see if the player had passed go. If they have add $200 to their bank
                    if (newPosition>40){
                        
                        //Wrap the board Position around to the begining
                        newPosition=newPosition-40;
                        
                        //Add $200 to the current Players bank
                        currentPlayer.setMoney(currentPlayer.getMoney()+200);
                        
                        
                    }

                    //Set the new loaction of the player
                    currentPlayer.setBoardLocation(newPosition);

                    //Get the square that the player is currently on
                    currentSquare=board.get(newPosition-1);

                    //Get the type that the current Square is
                    switch(currentSquare.getType()){
                        //If the type is property determine if it is purchased or not
                        case "property":
                                
                                //if the property is not purchased purchase it
                                if (currentSquare.getPurchased()==false){
                                    
                                    //Get the cost for the current property
                                    int cost=currentSquare.getCost();                                    

                                    //Update the currentPlayers bank to reflect purchase
                                    currentPlayer.setMoney(currentPlayer.getMoney()-cost);
                                    
                                    //update the currentSquare to be purchased, the next time a player lands on it they will not do anything
                                    currentSquare.setPurchased(true);   
                                    
                                    //TROUBLESHOOTING
                                    //System.out.println(currentSquare.getName() + " " + cost + " money: " + currentPlayer.getMoney());
                                }
                                //do nothing if the property is allready owned
                                else{
                                    //TROUBLESHOOTING
                                    //System.out.println(currentSquare.getName() + " purcased allready " + numTurns);
                                }
                            break;
                            
                        //If the type is penalty then pay the fine
                        case "penalty":
                            
                                //get the cost for the penalty
                                int cost=currentSquare.getCost();
                                
                                //Income Tax code, Find out whether 10% or 200 is greater
                                if (newPosition==4){
									//calculate 10% and round it to an int
                                    int tenPercent= (int) Math.round(currentPlayer.getMoney()*.1);
									
									//if 10% is higher then 200, use 10% for cost otherwise keep cost at 200
                                    if (tenPercent>200){
                                        cost=tenPercent;
                                    }
                                }
                                
                                
                                //TROUBLESHOOTING
                                //System.out.println("penalty " + cost);

                                //Update the currentPlayers bank to reflect the fine
                                currentPlayer.setMoney(currentPlayer.getMoney()-cost);
                            break;
                            
                        default:
                            //TroubleShooting 
                            //System.out.println("ERROR: switch went to defualt line 133");
                            break;
                    }

                    //Check for game End: if a player is below 0 balance or there have been 1000 rolls of the dice
                    if (currentPlayer.getMoney()<0 | numTurns==1000){
                        //TROUBLESHOOTING
                        //System.out.println("END OF GAME " + currentPlayer.getMoney() + " " + numTurns);
                        
                        //Update the total number of turns by adding the number in this game
                        totalNumRolls=numTurns+totalNumRolls;
                        
                        //Check if Indiana Ave is Purchased and record it
                        if (board.get(23).getPurchased()==true){
                            totalIndianaAvePurchased++;
                        }
                        
                        //Iterate through Board counting how many properties are purchased
                        for (int b=0;b<40;b++){
                            
                            square tempSquare=board.get(b);
                            //If the tempSquare is purchased add one to totalNumPropertyBought
                            if (tempSquare.getPurchased()==true){
                                totalNumPropertyBought++;                                
                            }
                            //reset the property to not purchased for another game
                            tempSquare.setPurchased(false);
                        }
                        
                        
                        //change play to false to stop the game while loop
                        play=false;                    
                    }

                    //Iterate numTurns Counter
                    ++numTurns;

                }//End of Play Loop
            }//End of simulation for-loop
            
            //TROUBLESHOOTING
            //System.out.println("total turns " + totalNumRolls);
            //System.out.println("totalNumPropertyBought " + totalNumPropertyBought);
            //System.out.println("totalIndianaAvePurchased " + totalIndianaAvePurchased);
            
            //Compute average number of rolls
            avgNumRolls=totalNumRolls/numToSimulate;
            
            //Compute the average number of properties bought per game
            avgNumPropertiesBaught=totalNumPropertyBought/numToSimulate;
            
            //Compute the percent of games in which Indiana Avenue was purchased
            percentIndianaAvePurchased=(totalIndianaAvePurchased/numToSimulate)*100;
            
            //Print out stats
            System.out.println("Stats for " + numToSimulate + " Games:");
            System.out.println("---------------------------------------");
            System.out.println("Average Number of turns per game was: " + avgNumRolls);
            System.out.println("Average Number of Properties Purchased Per Game was: " + avgNumPropertiesBaught);
            System.out.println("Indiana Avenue Was Purchased In " + percentIndianaAvePurchased + "% Of The Games.");
            
            
            
            //Out of Game Loop, Ask if user wants to play another game, if they do go back into the game loop by setting play to true          
            do{ //Loop for ensureing input is valid
                
                System.out.println("Would You Like To Play Again? Y/N");
                
                //get user input
                String input=scanner.nextLine();
                
                //Check to see if input was y or n or invalid and set play, quit, and inputValid accordingly
                switch (input) {
                    case "Y":
                    case "y":
                        play=true;
                        inputValid=true;
                        break;
                    case "N":
                    case "n":
                        quit=true;
                        inputValid=true;
                        break;
                    default:
                        System.out.println("Invalid input, Please Enter 'n' or 'y'");
                        inputValid=false;
                        break;
                }
            }while (inputValid==false); //End Valid Input do-while Loop
            
        }//End of QUIT While loop
        //Thank Users for playing my game =)
        System.out.println("===================================================");
        System.out.println("Thank You For Playing!");
        
        
    }//End of Main
    
     /**
     * Varify that input is an Int and return the int
     * @return int num
     */
    public static int promptForInt(){
        boolean inputValid=false;
        int num=0;
        do{ //Loop for ensureing input is valid
            Scanner numScanner=new Scanner(System.in);
               try{                   
                   num=numScanner.nextInt();
                   inputValid=true;
               }catch(java.util.InputMismatchException e){
                   System.out.println("Please Enter Only Numbers");
               }
        }while (inputValid==false); //End Valid Input do-while Loop
        return num;
    }
}
