package interviewprogram;

/**
 *
 * @author Nicholas
 */
public class square {
    private final String name, type;
    private final int cost;
    boolean purchased;
    
    //square Constructor
    square(String name, String type, int cost){
        this.name=name;
        this.type=type;
        this.cost=cost;
        purchased=false;
    }
    
    /**
     * Get The Cost of the Square
     * @return int cost
     */
    public int getCost(){
        return cost;
    }
    
     /**
     * Get The Name of the Square
     * @return String name
     */
    public String getName(){
        return name;
    }
    
     /**
     * Get Whether the square is purchased (<tt>true</tt>) or not (<tt>false</tt>)
     * @return boolean purchased
     */
    public boolean getPurchased(){
        return purchased;
    }
    
     /**
     * Set the square to purchased
     * @param purchased
     */
    public void setPurchased(boolean purchased){
        this.purchased=purchased;
    }
    
     /**
     * get The Type of the Square.
     * Either "property" or "penalty"
     * @return String type
     */
    public String getType(){
        return type;
    }
    
}
