/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package grades;

import grades.gradesui.MyDocumentFilter;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import static java.awt.event.ActionEvent.ALT_MASK;
import static java.awt.event.ActionEvent.CTRL_MASK;
import java.awt.event.MouseEvent;
import java.lang.reflect.Array;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.TableColumnModel;
import javax.swing.text.AbstractDocument;

    
/**
 *
 * @author Nicholas
 */
public class coursePanel extends course{
    private JTable courseGradeTable;
    private JPanel tabPanel,jPanel9;
    private JLabel jLabel17, courseDetailsName, jLabel19,courseDetailsTotalPoints,jLabel21,courseDetailsScoredPoints,jLabel23,courseDetailsCredits,jLabel28,courseDetailsGradePoints,jLabel30,jLabel29,courseDetailsGradeLetter,courseDetailsGradePercent,jLabel27,courseDetailsPointsPer;
    private JButton coursePanelDetailsButton,coursePanelDeleteButton, coursePanelAddAssignButton,coursePanelEditButton,coursePanelDelAssignButton,coursePanelFinalizeButton;
    private JScrollPane jScrollPane1,courseTableScrollPane;
    private javax.swing.JFormattedTextField numAssigns;
    gradesui.MyDocumentFilter documentFilter;
    private javax.swing.JDialog courseDetailsForm;
    //private JLabel courseDetailsNumAssigns;
    coursePanel(final JTable assignmentTable){
        super();
        numAssigns= new javax.swing.JFormattedTextField();
        ((AbstractDocument)numAssigns.getDocument()).setDocumentFilter(documentFilter);
        tabPanel = new javax.swing.JPanel();
        jPanel9 = new javax.swing.JPanel();
        jLabel17 = new javax.swing.JLabel();
        courseDetailsName = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        courseDetailsTotalPoints = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        courseDetailsScoredPoints = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        courseDetailsCredits = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        courseDetailsGradePoints = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        //courseDetailsNumAssigns = new javax.swing.JLabel();
        coursePanelDetailsButton = new javax.swing.JButton();
        coursePanelDeleteButton = new javax.swing.JButton();
        coursePanelAddAssignButton = new javax.swing.JButton();
        jLabel29 = new javax.swing.JLabel();
        courseDetailsGradeLetter = new javax.swing.JLabel();
        coursePanelEditButton = new javax.swing.JButton();
        courseDetailsGradePercent = new javax.swing.JLabel();
        coursePanelDelAssignButton = new javax.swing.JButton();
        jLabel27 = new javax.swing.JLabel();
        courseDetailsPointsPer = new javax.swing.JLabel();
        coursePanelFinalizeButton = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        courseGradeTable = new javax.swing.JTable();
        courseTableScrollPane = new javax.swing.JScrollPane();
        tabPanel.setPreferredSize(new java.awt.Dimension(681, 454));
        courseDetailsForm = new javax.swing.JDialog();
                courseDetailsForm.setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
                courseDetailsForm.setTitle("Course Details");
                courseDetailsForm.setAlwaysOnTop(false);
                courseDetailsForm.setBounds(new java.awt.Rectangle(0, 0, 650, 750));
                courseDetailsForm.setModalityType(java.awt.Dialog.ModalityType.APPLICATION_MODAL);
                courseDetailsForm.setType(java.awt.Window.Type.POPUP);
                courseDetailsForm.setLocationRelativeTo(null);
                courseDetailsForm.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosed(java.awt.event.WindowEvent evt) {
                        courseDetailsFormWindowClosed(evt);
                    }
                    public void courseDetailsFormWindowClosed(java.awt.event.WindowEvent evt) {
                        updateCourse();
                        
                        updateLabels();
                    }
                });
    

        jPanel9.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Course Details", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Times New Roman", 1, 14))); // NOI18N

        jLabel17.setText("Course Name: ");

        courseDetailsName.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));

        jLabel19.setText("Total Possible Points:");

        courseDetailsTotalPoints.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        courseDetailsTotalPoints.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        jLabel21.setText("Points Earned");

        courseDetailsScoredPoints.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        courseDetailsScoredPoints.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        jLabel23.setText("Credits");

        courseDetailsCredits.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED));

        jLabel28.setText("Current Grade Points: ");

        courseDetailsGradePoints.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        courseDetailsGradePoints.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        jLabel30.setText("Number Of Assignments");

        numAssigns.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        //courseDetailsNumAssigns.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        numAssigns.setEditable(true);
        numAssigns.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                numAssignsFocusLost(evt);
            }
        });
        coursePanelDetailsButton.setText("Details");
        coursePanelDetailsButton.setEnabled(true);
        coursePanelDetailsButton.addActionListener(new java.awt.event.ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                coursePanelDetailsButtonActionPerformed(ae);
            }
            public void coursePanelDetailsButtonActionPerformed(java.awt.event.ActionEvent evt) {
                courseDetailsForm.add(tabPanel);
                courseDetailsForm.setVisible(true);
            }
            
            
        });

        coursePanelDeleteButton.setText("Delete");
        coursePanelDeleteButton.setEnabled(true);
        coursePanelDeleteButton.addActionListener(new java.awt.event.ActionListener() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                coursePanelDeleteButtonActionPerformed(evt);
            }

            private void coursePanelDeleteButtonActionPerformed(ActionEvent evt) {
                throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }
        });

        coursePanelAddAssignButton.setText("Add Assign.");
        coursePanelAddAssignButton.setToolTipText("");
        coursePanelAddAssignButton.setEnabled(true);
        coursePanelAddAssignButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                coursePanelAddAssignButtonActionPerformed(evt);
            }

            private void coursePanelAddAssignButtonActionPerformed(ActionEvent evt) {
                //CURRENTLY NOT FUNCTIONING 
                if (evt.getModifiers()==ALT_MASK|evt.getModifiers()==CTRL_MASK){
                    System.out.println("addAssignbutton pressed with ctrl or alt");
                    //POP UP TO ASK FOR NUMBER OF ASSIGNMENTS TO ADD
                }
                else{
                    System.out.println("addAssignbutton pressed without modifier");
                    ((MyTableModel)assignmentTable.getModel()).addRow(getNewRowData());
                    setNumAssigns(getNumAssignments()+1, false);

                    
                }
             
            }
        });
        jLabel29.setText("Current Grade:");

        courseDetailsGradeLetter.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        courseDetailsGradeLetter.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        coursePanelEditButton.setText("Edit");
        coursePanelEditButton.setEnabled(true);
        coursePanelEditButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                coursePanelEditButtonActionPerformed(evt);
            }

            private void coursePanelEditButtonActionPerformed(ActionEvent evt) {
                showAddCourse();
            }
        });

        courseDetailsGradePercent.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        courseDetailsGradePercent.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        coursePanelDelAssignButton.setText("Del Assign.");
        coursePanelDelAssignButton.setToolTipText("");
        coursePanelDelAssignButton.setEnabled(true);
        coursePanelDelAssignButton.addActionListener(new java.awt.event.ActionListener() {
                    public void actionPerformed(java.awt.event.ActionEvent evt) {
                        coursePanelDelAssignButtonActionPerformed(evt);
                    }

                    private void coursePanelDelAssignButtonActionPerformed(ActionEvent evt) {
                        switch (coursePanelDelAssignButton.getText()){
                            case "OK":
                                int[] selected =assignmentTable.getSelectedRows();
                                int numSel=selected.length;
                                for(int i=0;i<numSel;i++){
                                    ((MyTableModel) assignmentTable.getModel()).removeRow(selected[i]-i);
                                    setNumAssigns(getNumAssignments()-1, false);
                                }
                                coursePanelDelAssignButton.setText("Del Assign");
                            break;
                            default:
                                JOptionPane.showMessageDialog(tabPanel,"Please Highlight Assignments to Delete and Click the \"OK\" Button. TIP: Ctr Click To Select Multiple Assignments","Delete Assignments", JOptionPane.INFORMATION_MESSAGE);
                                coursePanelDelAssignButton.setText("OK");
                            break;    
                        }
                    }
                        
                    
                });
        jLabel27.setText("Points per %");

        courseDetailsPointsPer.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        courseDetailsPointsPer.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        coursePanelFinalizeButton.setText("Finalize");
        coursePanelFinalizeButton.setEnabled(true);
        coursePanelFinalizeButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                coursePanelFinalizeButtonActionPerformed(evt);
            }

            private void coursePanelFinalizeButtonActionPerformed(ActionEvent evt) {
                throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }
        });

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel9Layout.createSequentialGroup()
                                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel17)
                                    .addComponent(jLabel23))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(courseDetailsCredits, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(courseDetailsName, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel9Layout.createSequentialGroup()
                                .addComponent(jLabel30)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(numAssigns, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addComponent(coursePanelAddAssignButton, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(coursePanelDelAssignButton)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addComponent(jLabel28)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(courseDetailsGradePoints, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addComponent(jLabel29)
                        .addGap(18, 18, 18)
                        .addComponent(courseDetailsGradeLetter, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(courseDetailsGradePercent, javax.swing.GroupLayout.DEFAULT_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addComponent(jLabel27)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(courseDetailsPointsPer, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel19)
                            .addComponent(jLabel21))
                        .addGap(13, 13, 13)
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(courseDetailsTotalPoints, javax.swing.GroupLayout.DEFAULT_SIZE, 46, Short.MAX_VALUE)
                            .addComponent(courseDetailsScoredPoints, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(coursePanelFinalizeButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(coursePanelDetailsButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(coursePanelEditButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(coursePanelDeleteButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(6, 6, 6))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel17)
                            .addComponent(courseDetailsName, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel23)
                            .addComponent(courseDetailsCredits, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(courseDetailsTotalPoints, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel19))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(courseDetailsScoredPoints, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel21))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(numAssigns, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel30)
                    .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(courseDetailsPointsPer, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel27)))
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(coursePanelAddAssignButton)
                            .addComponent(coursePanelDelAssignButton))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel9Layout.createSequentialGroup()
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel9Layout.createSequentialGroup()
                                .addGap(0, 0, 0)
                                .addComponent(jLabel29)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel9Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(courseDetailsGradeLetter, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(courseDetailsGradePercent, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(6, 6, 6)))
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel28)
                            .addComponent(courseDetailsGradePoints, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)))))
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGap(3, 3, 3)
                .addComponent(coursePanelDetailsButton)
                .addGap(0, 0, 0)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(coursePanelDeleteButton, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel9Layout.createSequentialGroup()
                        .addComponent(coursePanelEditButton)
                        .addGap(23, 23, 23)))
                .addGap(0, 0, 0)
                .addComponent(coursePanelFinalizeButton))
        );

        courseGradeTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {"A", null, null},
                {"B", null, null},
                {"C", null, null},
                {"D", null, null},
                {"F", null, null}
            },
            new String [] {
                "Grade", "Points Needed", "GPA Impact"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.Double.class, java.lang.Double.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        TableColumnModel courseGradeTableColumnModel= courseGradeTable.getColumnModel();
        courseGradeTableColumnModel.getColumn(0).setPreferredWidth(50);
        courseGradeTableColumnModel.getColumn(1).setPreferredWidth(95);
        courseGradeTableColumnModel.getColumn(2).setPreferredWidth(75);
        

        javax.swing.GroupLayout tabPanelLayout = new javax.swing.GroupLayout(tabPanel);
        tabPanel.setLayout(tabPanelLayout);
        tabPanelLayout.setHorizontalGroup(
            tabPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(tabPanelLayout.createSequentialGroup()
                .addGap(2, 2, 2)
                .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 234, Short.MAX_VALUE))
            .addComponent(courseTableScrollPane)
        );
        tabPanelLayout.setVerticalGroup(
            tabPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(tabPanelLayout.createSequentialGroup()
                .addGroup(tabPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(courseTableScrollPane, javax.swing.GroupLayout.DEFAULT_SIZE, 327, Short.MAX_VALUE))
        );
        jScrollPane1.setViewportView(courseGradeTable);
        courseTableScrollPane.setViewportView(assignmentTable);

}
    private void numAssignsFocusLost(java.awt.event.FocusEvent evt) {                                              
        if (numAssigns.getText().equals("")){}
        else {
            int input=Integer.parseInt(numAssigns.getText());
            super.setNumAssigns(input);
            
        }        
    }
        
    public void updateCoursePanel(String name, int credits,int numAssignments,Double totalPoints,Double scoredPoints){
       this.courseDetailsName.setText(name);
       this.courseDetailsCredits.setText(Integer.toString(credits));
       this.numAssigns.setText(Integer.toString(numAssignments));
       this.courseDetailsTotalPoints.setText(Double.toString(totalPoints));
       this.courseDetailsScoredPoints.setText(Double.toString(scoredPoints));
       this.courseDetailsPointsPer.setText(""+ (totalPoints*.01));
    }
    
    public JPanel getPanel(){
        return tabPanel;
    }
    public void setCourseDetailsGradePercent(String tempGradePercent){
        courseDetailsGradePercent.setText(tempGradePercent+"%");
    }
    public void setCourseDetailsGradeLetter(String letterGrade){
        courseDetailsGradeLetter.setText(letterGrade);
    }
    public void setCourseDetailsGradePoints(String gradePoints){
        courseDetailsGradePoints.setText(gradePoints);
    }
    public void setGPAChange(double[] gpaChange) {
        for (int i=0;i<5;i++){
            courseGradeTable.setValueAt(gpaChange[i],i,2);
        }
    }
    public void setPointsNeeded(int i, double points){
        courseGradeTable.setValueAt(points,i, 1);
    }
//    public void repaintTable(){
//        courseTableScrollPane.setViewportView(assignmentTable);
//        courseTableScrollPane.repaint();
//        assignmentTable.repaint();
//    }
    public void troubleshoot(){
        int rowCount=assignmentTable.getRowCount();
        int colCount=assignmentTable.getColumnCount();
        System.out.println("Number of rows" + rowCount +" number of Columns "+ colCount);
        for (int i=0;i<colCount;i++){
            for(int r=0;r<rowCount;r++){
                Object tempObject;
                try{                    
                    tempObject= assignmentTable.getValueAt(r, i);
                }catch(java.lang.NullPointerException e){
                    tempObject="null";
                }
                System.out.println("row: " + r+" col: "+i+ " "+ tempObject);
            }
        }
    }
//    public void setViewport(JTable table){
//        courseTableScrollPane.setViewportView(table);
//    }
    @Override
    public void getNameofClass(){
        System.out.println("coursePanel.java");
    }
    
}
