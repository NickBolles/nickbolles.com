/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package grades;

import java.awt.Component;
import java.util.*;
import javax.swing.JTabbedPane;


/**
 *
 * @author Nicholas
 */
public class Profile extends gradesui{
    private String name,termType;
    private boolean success=false;
    private double gpaScale,gpa;
    private int numCourses,gradePoints,credits, index,currentTermIndex;
    private ArrayList<String> termNames=new ArrayList();
    private ArrayList<term> terms;

    private ArrayList<course> tempCourses;
    private course currentCourse;
    private ArrayList<Component> tabs;
    
    Profile(){   
    }
    Profile(String name, String type, double gpaScale,int index){
        this.terms = new ArrayList();
        this.name=name;
        this.termType=type;
        this.gpaScale=gpaScale;
        this.gpa=0.0;
        this.numCourses=0;
        this.gradePoints=0;
        this.credits=0;
        this.index=index;
        this.currentTermIndex=0;
        this.tabs=new ArrayList();
    }

    public boolean addTerm(String name){
        for(int i=0;i<terms.size();i++){
            if (terms.get(i).getTermName().equals(name)){
              return success=false;  
            }
        }
        
        terms.add(new term(name, this));
        termNames.add(name);
        if (terms.size()>0){
            currentTermIndex=terms.size()-1;
        }
        System.out.println("number of terms is "+ terms.size());
        return success=true;       
    }
    public ArrayList getTerms(){
        return terms;
    }
    public ArrayList getTermNames(){
        return termNames;
    }
    public int getNumTerms(){
        return terms.size();
    }
    public void setCurrentTermIndex(int currentTerm){
        this.currentTermIndex=currentTerm;
    }
    public term getCurrentTerm(){
        return terms.get(currentTermIndex);
    }
    public int getCurrentTermIndex(){
        return currentTermIndex;
    }
    public void setName(String name){
        this.name=name;
    }
    public String getName(){
        return name;
    }
    public void setGpaScale(int gpaScale){
        this.gpaScale=gpaScale;
    }
    public double getProfileGpaScale(){
        return gpaScale;
    }
    public void setTermType(String termType){
        this.termType=termType;
    }
    public String getTermType(){
        return termType;
    }
    public void setGPA(double gpa){
        this.gpa=gpa;
    }
    public double getProfileGPA(){
        return gpa;
    }
    public void setProfileNumCourses(int numCourses){
        this.numCourses=numCourses;
    }
    public int getProfileNumCourses(){
        for (int i=0; i<terms.size();i++){
            numCourses=0;
            numCourses=numCourses+(terms.get(i).getNumCourses());
        }
        return numCourses;
    }
    public void setProfileGradePoints(int gradePoints){
        this.gradePoints=gradePoints;
    }
    public int getProfileGradePoints(){
        return gradePoints;
    }
    public void setCredits(int credits){
        this.credits=credits;
    }
    public int getProfileCredits(){
        return credits;
    }
    public void setProfileIndex(int index){
        this.index=index;
    }
    public int getProfileIndex(){
        return index;
    }
    public void getNameofClass(){
        System.out.println("coursePanel.java");
    }
}
