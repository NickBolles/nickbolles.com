/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package grades;

import grades.gradesui;
import java.text.DecimalFormat;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.TableColumn;
import javax.swing.table.TableModel;

/**
 *
 * @author Nicholas
 */
public class course extends term{
    private int credits, numAssignments, gradePoints;
    private Double totalPoints, scoredPoints, gradePercent;
    public JTable assignmentTable;
    private JPanel tabPanel;
    private coursePanel coursePanel;
    private boolean updatingCourse=false;
    private String courseName;
    course(){
        super();
    }
    course(String name, int credits, Double totalPoints, int numAssigns){
        super();
        assignmentTable=new JTable(new MyTableModel());
        TableColumn column0=assignmentTable.getColumnModel().getColumn(0);
        column0.setMaxWidth(10);
        column0.setPreferredWidth(10);
        column0.setResizable(false);
        courseName=name;
        this.credits=credits;
        this.totalPoints=totalPoints;
        scoredPoints=0.0;
        gradePercent=0.0;
        gradePoints=0;
        setNumAssigns(numAssigns);
        ((MyTableModel)assignmentTable.getModel()).setValueAt(6.9, 0, 2);
        JOptionPane.showMessageDialog(getAddCourse(),"New Course Created " + courseName,"New Course", JOptionPane.WARNING_MESSAGE);
        
   }
       
    public void createCoursePanel(){
        if (coursePanel==null){
            coursePanel=new coursePanel(assignmentTable);
//            coursePanel.setViewport(assignmentTable);
            updateCourse();
            System.out.println("CoursePanel has been created at line 56 of course.java");
        }
        else{
            System.out.println("Error CoursePanel allready created");
            System.out.println("Error CoursePanel allready created");
        }
    }

        
    public String getCourseName(){
        return courseName;
    }
    public void setCourseName(String name){
        JOptionPane.showMessageDialog(tabPanel,"Course Name Changed to  "+name,"Please Enter Credits", JOptionPane.WARNING_MESSAGE);
        this.courseName=name;
        
    }

    public JTable getAssignmentTable(){
        return assignmentTable;
    }
//    public void setAssignmentTable(JTable table){
//        assignmentTable.getModel()=table.getModel();
//    }
    
    public int getNumAssignments(){
        numAssignments=((MyTableModel)assignmentTable.getModel()).getRowCount();
        return numAssignments;
    }
    public Double getScoredPoints(){
        updateCourse();
        return scoredPoints;
    }
    public Double getTotalCoursePoints(){
        return totalPoints;
    }
    public void setTotalPoints(Double totalPoints){
        this.totalPoints=totalPoints;
    }
    public int getCourseCredits(){
        return credits;
    }
    public void setCourseCredits(int credits){
        this.credits=credits;
    }
    public void setGradePoints(int grade){
        this.gradePoints=this.credits*grade;
    }
    public int getGradePoints(){
        return gradePoints;
    }
    public JPanel getCoursePanel(){
        //coursePanel.troubleshoot();
        return coursePanel.getPanel();
    }
    public void setNumAssigns(int num, boolean nothing){
        numAssignments=num;
    }
    public void setNumAssigns(int input){
        if (coursePanel!=null){    
            int diff=0;
            MyTableModel model=(MyTableModel)assignmentTable.getModel();
            int numRows=model.getRowCount();
            if (numRows<input){
                //figure out how many rows to add
                diff=(input-numRows);
                for (int i=0; i<diff;i++){
                    model.addRow(getNewRowData());
                    numAssignments++;
                }
                System.out.println("DONE updating model with new rows");
                //Problem is in update rows!!!!
            }
        //ERROR IN REASONING. WHAT IF USER HAD DATA IN THE DELETED ROWS?    
            
            else if(numRows>input){
                //figure out how many rows to delete
                diff=(numRows-input);
                for (int i=0; i<diff ;i++){
                    model.removeRow(numRows-(i+1));
                    --numAssignments;
                }
                model.updateRows();
            }
            numAssignments=input;
            updateCourse();
        }
    }
    

    public Object[] getNewRowData(){
        return new Object[]{false,"",0.0,0.0,0.0,0.0};
    }
    public void addAssign(){
        MyTableModel model=(MyTableModel)assignmentTable.getModel();
        model.addRow(getNewRowData());
        model.updateRows();
        updateCourse();
    
    }
    public void delAssign(int row){
            MyTableModel model=(MyTableModel)assignmentTable.getModel();
            model.removeRow(row);
            model.updateRows();
            updateCourse();
    }    
    public void updateCourse(){
        updatingCourse=true;
        try{

            System.out.println("line 168 in update Labels in course.java");
            //coursePanel.troubleshoot();

            System.out.println("course update labels"+courseName);
            //TODO Update Labels codes
            ((MyTableModel)assignmentTable.getModel()).updateTableValues();
            
           DecimalFormat df = new DecimalFormat("###.##");
           gradePercent=(scoredPoints*100)/totalPoints;
           String tempGradePercent=df.format(gradePercent);
           coursePanel.setCourseDetailsGradePercent(tempGradePercent);
           Double[] gradeVals={0.9,0.8,0.7,0.6,0.5};
           if(gradePercent>=90){
               coursePanel.setCourseDetailsGradeLetter("A");
               setGradePoints(4);
           }
           else if(gradePercent<90 && gradePercent>=80){
               coursePanel.setCourseDetailsGradeLetter("B");
               setGradePoints(3);
           }
           else if(gradePercent<80 && gradePercent>=70){
               coursePanel.setCourseDetailsGradeLetter("C");
               setGradePoints(2);
           }
           else if(gradePercent<70 && gradePercent>=60){
               coursePanel.setCourseDetailsGradeLetter("D");
               setGradePoints(1);
           }
           else if(gradePercent<60){
               coursePanel.setCourseDetailsGradeLetter("F");
               setGradePoints(0);
           }
           else{
               coursePanel.setCourseDetailsGradeLetter("N/A");
               setGradePoints(0);
           }
           double gpaChange[]=new double[5];
           coursePanel.setCourseDetailsGradePoints(""+ gradePoints);

            //TODO TROUBLESHOOTING

           //calculating GPA impact. and setting the Table
           //Figure out how to get profile, because Course is part of a profi
           int profGradePoints=getProfileGradePoints();
           int profCredits=getProfileCredits();
           double currentCredits=credits+profCredits;
           if ((currentCredits)==0){
                gpaChange[0]=(profGradePoints+(4.0*credits))/(currentCredits);
                gpaChange[1]=(profGradePoints+(3.0*credits))/(currentCredits);
                gpaChange[2]=(profGradePoints+(2.0*credits))/(currentCredits);
                gpaChange[3]=(profGradePoints+(1.0*credits))/(currentCredits);
                gpaChange[4]=(profGradePoints/(currentCredits));
                coursePanel.setGPAChange(gpaChange);
           }
           else{
               for (int i=0;i<5;i++){
                    //gradeVals[i]=0.0;
                }
           }

            for (int i=0;i<5;i++){
                coursePanel.setPointsNeeded(i,totalPoints*gradeVals[i]);
           }
            coursePanel.updateCoursePanel(courseName, credits, numAssignments,totalPoints, scoredPoints);
        }catch(NullPointerException e){
            System.out.println("NullPointerException line 256 course.java: probably havent created course panel yet");
        }
        updatingCourse=false;

    }
    public void updateAll(){
        updateCourse();
       
        
    }
    
    
    
    
    
    class  MyTableModel extends AbstractTableModel {
        //EDIT IF COLUMN CHANGED
        private final String[] columnNames = {" ","Assignment Name", "Score","Points","weight","Percentage"};
        private final Class[] columnType = new Class [] {
                                                            java.lang.Boolean.class,
                                                            java.lang.String.class, 
                                                            java.lang.Double.class,
                                                            java.lang.Double.class, 
                                                            java.lang.Double.class, 
                                                            java.lang.Double.class
                                                        };
        
        
        
        private ArrayList<Boolean> check=new ArrayList<Boolean> () {{
            add(false);
        }};
        private ArrayList<String> assignmentNames=new ArrayList<String>() {{
            add("");
        }};
        private ArrayList<Double> scores=new ArrayList<Double>() {{
            add(.0);
        }};
        private ArrayList<Double> points=new ArrayList<Double>() {{
            add(.0);
        }};
        private ArrayList<Double> weight=new ArrayList<Double>() {{
            add(.0);
        }};
        private ArrayList<Double> gpaImpact=new ArrayList<Double>() {{
            add(.0);
        }};
        private ArrayList<ArrayList> data=new ArrayList() {{
                                                                add(check);
                                                                add(assignmentNames);
                                                                add(scores);
                                                                add(points);
                                                                add(weight);
                                                                add(gpaImpact);
                                                            }};       
        
        

        
        
        @Override
        public int getColumnCount() {
            return columnNames.length;
        }

        
        public int getRowCount() {
            int rowCount=0;
            try {
                rowCount=data.get(0).size();
            }catch(NullPointerException e){
                System.out.println("nullpointerexception in get row count in course");
                rowCount=0;
            }
            
            return rowCount;
        }

        @Override
        public String getColumnName(int col) {
            return columnNames[col];
        }

        @Override
        public Object getValueAt(int row, int col) {
            return data.get(col).get(row);
        }

        @Override
        public Class getColumnClass(int c) {
            return columnType[c];
        }
        
        public void updateRows(){
            System.out.println("UpdateRows() in model");
            fireTableRowsInserted(0, assignmentTable.getModel().getRowCount()-1);   
        }
        public void updateTableValues(){
              Double newValue=0.0;
              int numRows=this.getRowCount();
              scoredPoints=0.0;
              totalPoints=0.0;
              for(int row=0;row<numRows;row++){
                try{
                   Double tempScore=scores.get(row);
                   Double tempPoints= points.get(row);
                   newValue=(tempScore*100)/tempPoints;
                   gpaImpact.remove(row);
                   gpaImpact.add(row, newValue);
                   this.fireTableRowsUpdated(row, row);
                    }catch(NullPointerException error){
                       System.out.println("nullpointer exception on line 358");
                   }catch(java.lang.IndexOutOfBoundsException IOBE){
                       System.out.println("IndexOutOfBoundsException on line 360 in course, probably adding a row");
                   }
                   scoredPoints=scoredPoints + scores.get(row);
                   totalPoints=totalPoints + points.get(row);
              }
        }
        
        public void tableDataChanged(){
            this.fireTableDataChanged();
        }
        
        @Override
        public boolean isCellEditable(int row, int col) {
            //Note that the data/cell address is constant,
            //no matter where the cell appears onscreen.
            return col < 4;
        }

        /*
         * Don't need to implement this method unless your table's
         * data can change.
         */
        @Override
        public void setValueAt(Object value, int row, int col) {
            data.get(col).set(row, value);
            
            
            
            this.fireTableCellUpdated(row, col);
            if(updatingCourse==false){
                updateCourse();
            }
//            try{
//                coursePanel.troubleshoot();
//            }catch(java.lang.NullPointerException e){
//                System.out.println("nullpointer line 378 course.java course panel is probably not created yet");
//            }

        }
        
        public void addRow(Object [] rowData){
            int columns=data.size();            
            for (int d=0;d<columns;d++){
                data.get(d).add(rowData[d]);
                
//                setValueAt(rowData[d],(data.get(d).size()-1),d);
            }
            this.fireTableRowsInserted(data.get(0).size(), data.get(0).size());
            updateCourse();
            System.out.println("done adding Row");
        }

        public void removeRow(int rowIndex){
            int columns=data.size();            
            for (int d=0;d<columns;d++){
                data.get(d).remove(rowIndex);
            }
            fireTableRowsDeleted(rowIndex,rowIndex);
            updateCourse();
        }

        public ArrayList<Double> getScores(){
            return scores;
        }
        public ArrayList<Double> getTotalPoints(){
            return points;
        }
        
    }
    
    @Override
    public void getNameofClass(){
        System.out.println("course.java");
    }
    
}
