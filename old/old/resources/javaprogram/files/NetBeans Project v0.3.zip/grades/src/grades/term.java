/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package grades;

import java.util.ArrayList;
import javax.swing.JTable;

/**
 *
 * @author Nicholas
 */
public class term extends Profile{
    String name;
    private int numCourses, credits, currentCourseIndex;
    private ArrayList<course> courses;
    Profile profile;
    term(){
        super();
    }
    term(String name, Profile profile){
        //super(profile.getName(), profile.getTermType(),profile.getProfileGpaScale(),profile.getProfileIndex());
        super();
        this.profile=profile;
        this.name=name;
        this.credits=0;
        this.numCourses=0;
        courses=new ArrayList(0);
        
    }
    
    public Profile getProfile(){
        return profile;
    }
    public String getTermName(){
        return name;
    }
    public void setTermName(String name){
        this.name=name;
    }
    public ArrayList getCourseArray(){
        return courses;
    }
    public void setCurrentCourseIndex(int index){
        currentCourseIndex=index;
    }
    public int getCurrentCourseIndex(){
        return currentCourseIndex;
    }
    public course getCurrentCourse(){
        return courses.get(currentCourseIndex);
    }
    public int getCourseNum(){
        return numCourses;
    }
    public course getCourse(int i){
        return courses.get(i);
    }
    
    //TODO see if needed for loading
//    public void addCourse(String name, int credits, JTable table, Double totalPoints){
//        numCourses++;
//        courses.add(new course(name, credits, table, totalPoints));
//        this.credits=this.credits+credits;
//        
//    }
    public void addCourse(String name, int credits, Double totalPoints, int numAssigns){
        System.out.println("adding course line 58 term.java");
        courses.add(new course(name,credits,totalPoints,numAssigns));
        courses.get(courses.size()-1).setNumAssigns(numAssigns);
        
        System.out.println("term addcourse, course has been created");
        numCourses++;

    }
    public int getCredits(){
        return credits;
    }
    public int getNumCourses(){
        return numCourses;
    }
    @Override
    public void getNameofClass(){
        System.out.println("term.java");
    }
    
}
