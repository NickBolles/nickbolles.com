
package grades;

import grades.course.MyTableModel;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.text.DecimalFormat;
import java.util.*;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableModel;
import javax.swing.text.AbstractDocument;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.DocumentFilter;
import javax.swing.text.DocumentFilter.FilterBypass;
/**
 *
 * @author Nicholas
 */
public class gradesui extends javax.swing.JFrame {
    boolean addingTab=false, addingProfile=false, firstProfile=true, success=false,updateSelectedTab=false, addATab=true, tabChanged=false;
    int numProfiles, currentTab, numTerms, termsSize, currentCourseIndex;
    double gradePointScaleSelectedValue=0;
    String termTypeSelectedValue, columnNames[];
    Profile currentProfile;        
    term currentTerm;
    ArrayList<Profile> profiles;
    ArrayList<String> termNames;
    MyDocumentFilter documentFilter;
    course currentCourse;
    JTable currentCourseTable;
    long timeStored;

    public gradesui() {
        this.columnNames = new String[]{"Assignment Name", "Points", "Score"};
        this.profiles = new ArrayList(0);
        currentTab=0;
        numTerms=0;
        termsSize=0;
        currentCourseIndex=0;
        timeStored=0;
        
        
        initComponents();

    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        bindingGroup = new org.jdesktop.beansbinding.BindingGroup();

        addProfile = new javax.swing.JDialog();
        profileNameInput = new javax.swing.JFormattedTextField();
        addProfileConfirm = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        termTypeSemester = new javax.swing.JRadioButton();
        termTypeTrimester = new javax.swing.JRadioButton();
        termTypeQuarter = new javax.swing.JRadioButton();
        jPanel5 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        pointScale12 = new javax.swing.JRadioButton();
        pointScale10 = new javax.swing.JRadioButton();
        pointScale4 = new javax.swing.JRadioButton();
        addProfileCancel = new javax.swing.JButton();
        addTerm = new javax.swing.JDialog();
        jLabel5 = new javax.swing.JLabel();
        addTermYearSlider = new javax.swing.JSlider();
        addTermYearTextBox = new javax.swing.JFormattedTextField();
        addTermConfirmButton = new javax.swing.JButton();
        addTermCancelButton = new javax.swing.JButton();
        addTermSemester = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        semesterFall = new javax.swing.JRadioButton();
        semesterSpring = new javax.swing.JRadioButton();
        semesterOther = new javax.swing.JRadioButton();
        addTermQuarter = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        quarter1 = new javax.swing.JRadioButton();
        quarter2 = new javax.swing.JRadioButton();
        quarterOther = new javax.swing.JRadioButton();
        quarter3 = new javax.swing.JRadioButton();
        addTermTrimester = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        trimester1 = new javax.swing.JRadioButton();
        trimester2 = new javax.swing.JRadioButton();
        trimester3 = new javax.swing.JRadioButton();
        trimesterOther = new javax.swing.JRadioButton();
        addCourse = new javax.swing.JDialog();
        jLabel6 = new javax.swing.JLabel();
        courseNameInput = new javax.swing.JFormattedTextField();
        jLabel7 = new javax.swing.JLabel();
        creditTextBox = new javax.swing.JTextField();
        ((AbstractDocument)creditTextBox.getDocument()).setDocumentFilter(new MyDocumentFilter());
        jPanel7 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        addCourseNumAssigns = new javax.swing.JFormattedTextField();
        ((AbstractDocument)addCourseNumAssigns.getDocument()).setDocumentFilter(new MyDocumentFilter());
        addCourseTotalPoints = new javax.swing.JFormattedTextField();
        ((AbstractDocument)addCourseTotalPoints.getDocument()).setDocumentFilter(new MyDocumentFilter());
        jButton2 = new javax.swing.JButton();
        addCourseCancelButton = new javax.swing.JButton();
        addCourseConfirmButton = new javax.swing.JButton();
        addCourseButton = new javax.swing.JButton();
        addTermQuarterButton = new javax.swing.ButtonGroup();
        addProfileGradePointScale = new javax.swing.ButtonGroup();
        addProfileTermType = new javax.swing.ButtonGroup();
        addTermSemesterButton = new javax.swing.ButtonGroup();
        AddTermTrimesterButton = new javax.swing.ButtonGroup();
        aboutWindow = new javax.swing.JFrame();
        jPanel1 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jDialog1 = new javax.swing.JDialog();
        demo = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        demo2 = new javax.swing.JPanel();
        jPanel10 = new javax.swing.JPanel();
        jLabel18 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        courseGradeTable1 = new javax.swing.JTable();
        troubleshoot = new javax.swing.JFrame();
        jScrollPane1 = new javax.swing.JScrollPane();
        jList1 = new javax.swing.JList();
        jScrollPane2 = new javax.swing.JScrollPane();
        course = new javax.swing.JList();
        profilePanel = new javax.swing.JPanel();
        profileComboBox = new javax.swing.JComboBox();
        addProfileButton = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        profileDetailsTermTypeLabel = new javax.swing.JLabel();
        profileDetailsTermType = new javax.swing.JLabel();
        profileDetailsGradePointScaleLabel = new javax.swing.JLabel();
        profileDetailsGradePointScale = new javax.swing.JLabel();
        profileDetailsNumCoursesLabel = new javax.swing.JLabel();
        profileDetailsNumCourses = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        profileDetailGPALabel = new javax.swing.JLabel();
        profileDetailsGPA = new javax.swing.JLabel();
        profileDetailsCreditsTakenLabel = new javax.swing.JLabel();
        profileDetailsCreditsTaken = new javax.swing.JLabel();
        profileDetailsGradePointsLabel = new javax.swing.JLabel();
        profileDetailsGradePoints = new javax.swing.JLabel();
        jButton7 = new javax.swing.JButton();
        jButton9 = new javax.swing.JButton();
        jButton8 = new javax.swing.JButton();
        filler1 = new javax.swing.Box.Filler(new java.awt.Dimension(10, 0), new java.awt.Dimension(10, 0), new java.awt.Dimension(10, 32767));
        courseTabPane = new javax.swing.JTabbedPane();
        termPanel = new javax.swing.JPanel();
        termComboBox = new javax.swing.JComboBox();
        addTermButton = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        termDetailsCourses = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        termDetailsCredits = new javax.swing.JLabel();
        menuBar = new javax.swing.JMenuBar();
        fileMenu = new javax.swing.JMenu();
        exitMenuItem = new javax.swing.JMenuItem();
        helpMenu = new javax.swing.JMenu();
        aboutMenuItem = new javax.swing.JMenuItem();

        addProfile.setTitle("Create New Profile");
        addProfile.setAlwaysOnTop(true);
        addProfile.setBounds(new java.awt.Rectangle(0, 0, 480, 230));
        addProfile.setModalityType(java.awt.Dialog.ModalityType.APPLICATION_MODAL);
        addProfile.setLocationRelativeTo(null);
        addProfile.addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowActivated(java.awt.event.WindowEvent evt) {
                addProfileWindowActivated(evt);
            }
        });

        profileNameInput.setToolTipText("");
        profileNameInput.setName("profileNameInput"); // NOI18N

        addProfileConfirm.setText("Create Profile");
        addProfileConfirm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addProfileConfirmActionPerformed(evt);
            }
        });

        jLabel2.setText("Profile Name: ");

        jPanel3.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel3.setText("Academic Term Type");

        addProfileTermType.add(termTypeSemester);
        termTypeSemester.setSelected(true);
        termTypeSemester.setText("Semester");

        addProfileTermType.add(termTypeTrimester);
        termTypeTrimester.setText("Trimester");

        addProfileTermType.add(termTypeQuarter);
        termTypeQuarter.setText("Quarter");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(termTypeTrimester)
                            .addComponent(termTypeSemester)
                            .addComponent(termTypeQuarter))))
                .addContainerGap(84, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(termTypeSemester)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(termTypeTrimester)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(termTypeQuarter)
                .addContainerGap(15, Short.MAX_VALUE))
        );

        jPanel5.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel4.setText("Grade Point Scale");

        addProfileGradePointScale.add(pointScale12);
        pointScale12.setText("12 Point Scale");

        addProfileGradePointScale.add(pointScale10);
        pointScale10.setText("10 Point Scale");

        addProfileGradePointScale.add(pointScale4);
        pointScale4.setSelected(true);
        pointScale4.setText("4 Point Scale (Most Common)");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(pointScale10)
                            .addComponent(pointScale4)
                            .addComponent(pointScale12))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel4)
                .addGap(7, 7, 7)
                .addComponent(pointScale4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(pointScale10)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(pointScale12)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        addProfileCancel.setText("Cancel");
        addProfileCancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addProfileCancelActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout addProfileLayout = new javax.swing.GroupLayout(addProfile.getContentPane());
        addProfile.getContentPane().setLayout(addProfileLayout);
        addProfileLayout.setHorizontalGroup(
            addProfileLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
            .addGroup(addProfileLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(addProfileLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(addProfileLayout.createSequentialGroup()
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(profileNameInput, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 17, Short.MAX_VALUE)
                .addGroup(addProfileLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(addProfileLayout.createSequentialGroup()
                        .addComponent(addProfileCancel, javax.swing.GroupLayout.DEFAULT_SIZE, 100, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(addProfileConfirm)))
                .addContainerGap())
        );
        addProfileLayout.setVerticalGroup(
            addProfileLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, addProfileLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(addProfileLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(addProfileLayout.createSequentialGroup()
                        .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(18, 18, 18)
                        .addGroup(addProfileLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(addProfileConfirm)
                            .addComponent(addProfileCancel)))
                    .addGroup(addProfileLayout.createSequentialGroup()
                        .addGroup(addProfileLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(profileNameInput)
                            .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );

        addTerm.setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        addTerm.setTitle("Add a Term...");
        addTerm.setAlwaysOnTop(true);
        addTerm.setBounds(new java.awt.Rectangle(0, 0, 400, 400));
        addTerm.setModalityType(java.awt.Dialog.ModalityType.APPLICATION_MODAL);
        addTerm.setType(java.awt.Window.Type.POPUP);
        addTerm.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                addTermKeyPressed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel5.setText("Term Year: ");

        addTermYearSlider.setMajorTickSpacing(2);
        addTermYearSlider.setMaximum(2020);
        addTermYearSlider.setMinimum(2010);
        addTermYearSlider.setMinorTickSpacing(1);
        addTermYearSlider.setPaintLabels(true);
        addTermYearSlider.setPaintTicks(true);
        addTermYearSlider.setSnapToTicks(true);
        addTermYearSlider.setToolTipText("");

        addTermYearTextBox.setEditable(false);
        addTermYearTextBox.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("####"))));
        addTermYearTextBox.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        addTermYearTextBox.setMargin(new java.awt.Insets(1, 1, 1, 1));

        org.jdesktop.beansbinding.Binding binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, addTermYearSlider, org.jdesktop.beansbinding.ELProperty.create("${value}"), addTermYearTextBox, org.jdesktop.beansbinding.BeanProperty.create("value"));
        bindingGroup.addBinding(binding);

        addTermYearTextBox.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                addTermYearTextBoxKeyTyped(evt);
            }
        });

        addTermConfirmButton.setText("Add Term");
        addTermConfirmButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addTermConfirmButtonActionPerformed(evt);
            }
        });

        addTermCancelButton.setText("Cancel");
        addTermCancelButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addTermCancelButtonActionPerformed(evt);
            }
        });

        addTermSemester.setEnabled(false);
        addTermSemester.setPreferredSize(new java.awt.Dimension(296, 44));

        jLabel12.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel12.setText("Semester:");

        addTermSemesterButton.add(semesterFall);
        semesterFall.setText("Fall");

        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, addTermSemester, org.jdesktop.beansbinding.ELProperty.create("${enabled}"), semesterFall, org.jdesktop.beansbinding.BeanProperty.create("enabled"));
        bindingGroup.addBinding(binding);

        addTermSemesterButton.add(semesterSpring);
        semesterSpring.setText("Spring");

        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, addTermSemester, org.jdesktop.beansbinding.ELProperty.create("${enabled}"), semesterSpring, org.jdesktop.beansbinding.BeanProperty.create("enabled"));
        bindingGroup.addBinding(binding);

        addTermSemesterButton.add(semesterOther);
        semesterOther.setText("Other");

        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, addTermSemester, org.jdesktop.beansbinding.ELProperty.create("${enabled}"), semesterOther, org.jdesktop.beansbinding.BeanProperty.create("enabled"));
        bindingGroup.addBinding(binding);

        javax.swing.GroupLayout addTermSemesterLayout = new javax.swing.GroupLayout(addTermSemester);
        addTermSemester.setLayout(addTermSemesterLayout);
        addTermSemesterLayout.setHorizontalGroup(
            addTermSemesterLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(addTermSemesterLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel12)
                .addGap(18, 18, 18)
                .addComponent(semesterFall)
                .addGap(18, 18, 18)
                .addComponent(semesterSpring)
                .addGap(18, 18, 18)
                .addComponent(semesterOther)
                .addContainerGap(21, Short.MAX_VALUE))
        );
        addTermSemesterLayout.setVerticalGroup(
            addTermSemesterLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(addTermSemesterLayout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(addTermSemesterLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel12)
                    .addComponent(semesterFall)
                    .addComponent(semesterSpring)
                    .addComponent(semesterOther))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        addTermQuarter.setEnabled(false);
        addTermQuarter.setPreferredSize(new java.awt.Dimension(296, 70));

        jLabel14.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel14.setText("Quarter:");

        addTermQuarterButton.add(quarter1);
        quarter1.setText("One");

        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, addTermQuarter, org.jdesktop.beansbinding.ELProperty.create("${enabled}"), quarter1, org.jdesktop.beansbinding.BeanProperty.create("enabled"));
        bindingGroup.addBinding(binding);

        addTermQuarterButton.add(quarter2);
        quarter2.setText("Two");

        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, addTermQuarter, org.jdesktop.beansbinding.ELProperty.create("${enabled}"), quarter2, org.jdesktop.beansbinding.BeanProperty.create("enabled"));
        bindingGroup.addBinding(binding);

        addTermQuarterButton.add(quarterOther);
        quarterOther.setText("Other");

        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, addTermQuarter, org.jdesktop.beansbinding.ELProperty.create("${enabled}"), quarterOther, org.jdesktop.beansbinding.BeanProperty.create("enabled"));
        bindingGroup.addBinding(binding);

        addTermQuarterButton.add(quarter3);
        quarter3.setText("Three");

        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, addTermQuarter, org.jdesktop.beansbinding.ELProperty.create("${enabled}"), quarter3, org.jdesktop.beansbinding.BeanProperty.create("enabled"));
        bindingGroup.addBinding(binding);

        javax.swing.GroupLayout addTermQuarterLayout = new javax.swing.GroupLayout(addTermQuarter);
        addTermQuarter.setLayout(addTermQuarterLayout);
        addTermQuarterLayout.setHorizontalGroup(
            addTermQuarterLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(addTermQuarterLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(quarter1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(quarter2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(quarter3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(quarterOther)
                .addContainerGap(13, Short.MAX_VALUE))
        );
        addTermQuarterLayout.setVerticalGroup(
            addTermQuarterLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(addTermQuarterLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(addTermQuarterLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel14)
                    .addComponent(quarter1)
                    .addComponent(quarter2)
                    .addComponent(quarter3)
                    .addComponent(quarterOther))
                .addContainerGap(17, Short.MAX_VALUE))
        );

        addTermTrimester.setEnabled(false);
        addTermTrimester.setPreferredSize(new java.awt.Dimension(296, 70));

        jLabel13.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel13.setText("Trimester:");

        AddTermTrimesterButton.add(trimester1);
        trimester1.setText("One");

        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, addTermTrimester, org.jdesktop.beansbinding.ELProperty.create("${enabled}"), trimester1, org.jdesktop.beansbinding.BeanProperty.create("enabled"));
        bindingGroup.addBinding(binding);

        AddTermTrimesterButton.add(trimester2);
        trimester2.setText("Two");

        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, addTermTrimester, org.jdesktop.beansbinding.ELProperty.create("${enabled}"), trimester2, org.jdesktop.beansbinding.BeanProperty.create("enabled"));
        bindingGroup.addBinding(binding);

        AddTermTrimesterButton.add(trimester3);
        trimester3.setText("Three");

        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, addTermTrimester, org.jdesktop.beansbinding.ELProperty.create("${enabled}"), trimester3, org.jdesktop.beansbinding.BeanProperty.create("enabled"));
        bindingGroup.addBinding(binding);

        AddTermTrimesterButton.add(trimesterOther);
        trimesterOther.setText("Other");

        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, addTermTrimester, org.jdesktop.beansbinding.ELProperty.create("${enabled}"), trimesterOther, org.jdesktop.beansbinding.BeanProperty.create("enabled"));
        bindingGroup.addBinding(binding);

        javax.swing.GroupLayout addTermTrimesterLayout = new javax.swing.GroupLayout(addTermTrimester);
        addTermTrimester.setLayout(addTermTrimesterLayout);
        addTermTrimesterLayout.setHorizontalGroup(
            addTermTrimesterLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(addTermTrimesterLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel13)
                .addGap(18, 18, 18)
                .addComponent(trimester1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(trimester2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(trimester3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(trimesterOther)
                .addContainerGap(35, Short.MAX_VALUE))
        );
        addTermTrimesterLayout.setVerticalGroup(
            addTermTrimesterLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, addTermTrimesterLayout.createSequentialGroup()
                .addContainerGap(23, Short.MAX_VALUE)
                .addGroup(addTermTrimesterLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel13)
                    .addComponent(trimester1)
                    .addComponent(trimester2)
                    .addComponent(trimester3)
                    .addComponent(trimesterOther))
                .addContainerGap())
        );

        javax.swing.GroupLayout addTermLayout = new javax.swing.GroupLayout(addTerm.getContentPane());
        addTerm.getContentPane().setLayout(addTermLayout);
        addTermLayout.setHorizontalGroup(
            addTermLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(addTermLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(addTermLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(addTermLayout.createSequentialGroup()
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(addTermLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(addTermLayout.createSequentialGroup()
                                .addComponent(addTermCancelButton)
                                .addGap(68, 68, 68)
                                .addComponent(addTermConfirmButton)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(addTermLayout.createSequentialGroup()
                                .addComponent(addTermYearTextBox, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(addTermYearSlider, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                    .addGroup(addTermLayout.createSequentialGroup()
                        .addGroup(addTermLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(addTermTrimester, javax.swing.GroupLayout.DEFAULT_SIZE, 327, Short.MAX_VALUE)
                            .addComponent(addTermQuarter, javax.swing.GroupLayout.DEFAULT_SIZE, 327, Short.MAX_VALUE)
                            .addComponent(addTermSemester, javax.swing.GroupLayout.DEFAULT_SIZE, 327, Short.MAX_VALUE))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        addTermLayout.setVerticalGroup(
            addTermLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(addTermLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(addTermLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(addTermYearSlider, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(addTermLayout.createSequentialGroup()
                        .addGap(9, 9, 9)
                        .addGroup(addTermLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(addTermYearTextBox, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5))))
                .addGap(18, 18, 18)
                .addComponent(addTermSemester, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(addTermTrimester, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(addTermQuarter, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(addTermLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(addTermConfirmButton)
                    .addComponent(addTermCancelButton))
                .addContainerGap())
        );

        addCourse.setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        addCourse.setTitle("Add a Class");
        addCourse.setAlwaysOnTop(true);
        addCourse.setBounds(new java.awt.Rectangle(0, 0, 400, 250));
        addCourse.setModalityType(java.awt.Dialog.ModalityType.APPLICATION_MODAL);
        addCourse.setType(java.awt.Window.Type.POPUP);
        addCourse.addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosed(java.awt.event.WindowEvent evt) {
                addCourseWindowClosed(evt);
            }
            public void windowOpened(java.awt.event.WindowEvent evt) {
                addCourseWindowOpened(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel6.setText("Course Name: ");

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel7.setText("Credits: ");

        jPanel7.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel8.setText("Total Points (If Known): ");

        jLabel9.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel9.setText("Number of Assignments (If Known): ");

        addCourseNumAssigns.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                addCourseNumAssignsFocusLost(evt);
            }
        });
        addCourseNumAssigns.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addCourseNumAssignsActionPerformed(evt);
            }
        });

        jButton2.setText("Customize Grading Scale");
        jButton2.setEnabled(false);

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton2)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel9)
                            .addComponent(jLabel8))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(addCourseTotalPoints, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(addCourseNumAssigns, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(addCourseNumAssigns, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(14, 14, 14)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(addCourseTotalPoints, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(14, 14, 14)
                .addComponent(jButton2)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        addCourseCancelButton.setText("Cancel");
        addCourseCancelButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addCourseCancelButtonActionPerformed(evt);
            }
        });

        addCourseConfirmButton.setText("Add Course");
        addCourseConfirmButton.setMaximumSize(new java.awt.Dimension(50, 20));
        addCourseConfirmButton.setMinimumSize(new java.awt.Dimension(50, 20));
        addCourseConfirmButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addCourseConfirmButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout addCourseLayout = new javax.swing.GroupLayout(addCourse.getContentPane());
        addCourse.getContentPane().setLayout(addCourseLayout);
        addCourseLayout.setHorizontalGroup(
            addCourseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(addCourseLayout.createSequentialGroup()
                .addGroup(addCourseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(addCourseLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(addCourseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(addCourseLayout.createSequentialGroup()
                                .addComponent(jLabel6)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(courseNameInput, javax.swing.GroupLayout.PREFERRED_SIZE, 156, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(27, 27, 27)
                                .addComponent(jLabel7)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(creditTextBox, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(addCourseLayout.createSequentialGroup()
                        .addGap(83, 83, 83)
                        .addComponent(addCourseCancelButton)
                        .addGap(39, 39, 39)
                        .addComponent(addCourseConfirmButton, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        addCourseLayout.setVerticalGroup(
            addCourseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(addCourseLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(addCourseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(courseNameInput, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7)
                    .addComponent(creditTextBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(7, 7, 7)
                .addGroup(addCourseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(addCourseCancelButton)
                    .addComponent(addCourseConfirmButton, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        addCourseButton.setFont(new java.awt.Font("Lucida Calligraphy", 1, 36)); // NOI18N
        addCourseButton.setText("Click Here to Add a Course");
        addCourseButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addCourseButtonActionPerformed(evt);
            }
        });

        aboutWindow.setAlwaysOnTop(true);

        jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel11.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel11.setText("Created By: Nicholas Bolles");

        jLabel15.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        jLabel15.setText("Grade Analyzer");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel15)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(jLabel11)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel15)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel11)
                .addContainerGap(140, Short.MAX_VALUE))
        );

        jLabel16.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel16.setText("Bugs and FeedBack:");

        jTextField1.setEditable(false);
        jTextField1.setText("Nickbolles@live.com");
        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout aboutWindowLayout = new javax.swing.GroupLayout(aboutWindow.getContentPane());
        aboutWindow.getContentPane().setLayout(aboutWindowLayout);
        aboutWindowLayout.setHorizontalGroup(
            aboutWindowLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(aboutWindowLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(aboutWindowLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(aboutWindowLayout.createSequentialGroup()
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(aboutWindowLayout.createSequentialGroup()
                        .addComponent(jLabel16)
                        .addGap(18, 18, 18)
                        .addComponent(jTextField1)))
                .addContainerGap())
        );
        aboutWindowLayout.setVerticalGroup(
            aboutWindowLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(aboutWindowLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(aboutWindowLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel16, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jTextField1))
                .addContainerGap(104, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jDialog1Layout = new javax.swing.GroupLayout(jDialog1.getContentPane());
        jDialog1.getContentPane().setLayout(jDialog1Layout);
        jDialog1Layout.setHorizontalGroup(
            jDialog1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        jDialog1Layout.setVerticalGroup(
            jDialog1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {"Assignment 1",  new Double(5.0),  new Double(10.0), "50%",  new Double(0.1), "", null, null, null, null, "Click Here!"},
                {"Assignment 2",  new Double(3.0),  new Double(10.0), "30%",  new Double(0.1), null, null, null, null, null, "Click Here!"},
                {"Assignment 3",  new Double(9.0),  new Double(10.0), "90%",  new Double(0.1), null, null, null, null, null, "Click Here!"},
                {"Assignment 4",  new Double(7.0),  new Double(10.0), "70%",  new Double(0.1), null, null, null, null, null, "Click Here!"},
                {"Assignment 5",  new Double(8.0),  new Double(10.0), "80%",  new Double(0.1), null, null, null, null, null, "Click Here!"},
                {"Assignment 6",  new Double(7.0),  new Double(10.0), "70%",  new Double(0.1), null, null, null, null, null, "Click Here!"},
                {"Assignment 7",  new Double(9.0),  new Double(10.0), "90%",  new Double(0.1), null, null, null, null, null, "Click Here!"},
                {"Assignment 8",  new Double(10.0),  new Double(10.0), "100%",  new Double(0.1), null, null, null, null, null, "Click Here!"},
                {"Assignment 9",  new Double(10.0),  new Double(10.0), "100%",  new Double(0.1), null, null, null, null, null, "Click Here!"},
                {"Assignment 10",  new Double(10.0),  new Double(10.0), "100%",  new Double(0.1), null, null, null, null, null, "Click Here!"},
                {null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Assignment Name", "Points Scored", "Points Possible", "% score", "Weight", "impact GPA A", "impact GPA B", "impact GPA C", "impact GPA D", "impact GPA F", "Details"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.Double.class, java.lang.Double.class, java.lang.Object.class, java.lang.Double.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane3.setViewportView(jTable1);

        javax.swing.GroupLayout demoLayout = new javax.swing.GroupLayout(demo);
        demo.setLayout(demoLayout);
        demoLayout.setHorizontalGroup(
            demoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 509, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        demoLayout.setVerticalGroup(
            demoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        jPanel10.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createEtchedBorder(), "Assignment Details", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Times New Roman", 1, 14))); // NOI18N

        jLabel18.setText("Assignment Name:");

        jLabel20.setText("Assignment 1");
        jLabel20.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));

        jLabel22.setText("Weight");

        jLabel24.setText("10% of grade");
        jLabel24.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));

        jLabel25.setText("Total Points");

        jLabel26.setText("5");
        jLabel26.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));

        courseGradeTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {"A",  new Double(9.0),  new Double(0.9),  new Double(0.1)},
                {"B",  new Double(8.0),  new Double(0.8),  new Double(-0.1)},
                {"C",  new Double(7.0),  new Double(0.7),  new Double(-0.01)},
                {"D",  new Double(6.0),  new Double(0.6),  new Double(-0.1)},
                {"F",  new Double(5.0),  new Double(0.5),  new Double(-0.5)}
            },
            new String [] {
                "Grade", "Points Needed", "Course grade impact", "GPA Impact"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.Double.class, java.lang.Double.class, java.lang.Double.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane4.setViewportView(courseGradeTable1);

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addGap(4, 4, 4)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addComponent(jLabel18)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel20))
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel22)
                            .addComponent(jLabel25))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel26, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel24, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 239, Short.MAX_VALUE))
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel18)
                    .addComponent(jLabel20))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel25)
                    .addComponent(jLabel26))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel22)
                    .addComponent(jLabel24))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 11, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout demo2Layout = new javax.swing.GroupLayout(demo2);
        demo2.setLayout(demo2Layout);
        demo2Layout.setHorizontalGroup(
            demo2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        demo2Layout.setVerticalGroup(
            demo2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(demo2Layout.createSequentialGroup()
                .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 44, Short.MAX_VALUE))
        );

        troubleshoot.setMinimumSize(new java.awt.Dimension(500, 500));

        jList1.setModel(new javax.swing.AbstractListModel() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public Object getElementAt(int i) { return strings[i]; }
        });
        jScrollPane1.setViewportView(jList1);

        course.setModel(new javax.swing.AbstractListModel() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public Object getElementAt(int i) { return strings[i]; }
        });
        jScrollPane2.setViewportView(course);

        javax.swing.GroupLayout troubleshootLayout = new javax.swing.GroupLayout(troubleshoot.getContentPane());
        troubleshoot.getContentPane().setLayout(troubleshootLayout);
        troubleshootLayout.setHorizontalGroup(
            troubleshootLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(troubleshootLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(36, 36, 36)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(137, Short.MAX_VALUE))
        );
        troubleshootLayout.setVerticalGroup(
            troubleshootLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(troubleshootLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(troubleshootLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 233, Short.MAX_VALUE)
                    .addComponent(jScrollPane1))
                .addContainerGap(56, Short.MAX_VALUE))
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBounds(new java.awt.Rectangle(0, 0, 683, 736));

        profilePanel.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createEtchedBorder(), "Profile", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Times New Roman", 0, 18))); // NOI18N

        profileComboBox.setMaximumRowCount(10);
        profileComboBox.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Create a Profile>>" }));
        profileComboBox.setToolTipText("Click The '+' To Add A Profile");
        profileComboBox.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                profileComboBoxItemStateChanged(evt);
            }
        });

        addProfileButton.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        addProfileButton.setText("+");
        addProfileButton.setAlignmentY(0.0F);
        addProfileButton.setBorder(null);
        addProfileButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        addProfileButton.setMaximumSize(new java.awt.Dimension(24, 27));
        addProfileButton.setMinimumSize(new java.awt.Dimension(24, 27));
        addProfileButton.setPreferredSize(new java.awt.Dimension(24, 27));
        addProfileButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addProfileButtonActionPerformed(evt);
            }
        });

        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder("Profile Information"));

        profileDetailsTermTypeLabel.setText("Academic Term Type:");

        profileDetailsTermType.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED));

        profileDetailsGradePointScaleLabel.setText("Grade Point Scale: ");

        profileDetailsGradePointScale.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED));

        profileDetailsNumCoursesLabel.setText("Number of Courses: ");

        profileDetailsNumCourses.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED));

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap(12, Short.MAX_VALUE)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(profileDetailsTermTypeLabel)
                    .addComponent(profileDetailsGradePointScaleLabel)
                    .addComponent(profileDetailsNumCoursesLabel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(profileDetailsGradePointScale, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 80, Short.MAX_VALUE)
                    .addComponent(profileDetailsNumCourses, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(profileDetailsTermType, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(10, 10, 10))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(profileDetailsTermTypeLabel)
                    .addComponent(profileDetailsTermType, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(profileDetailsGradePointScaleLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(profileDetailsGradePointScale, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(profileDetailsNumCoursesLabel)
                    .addComponent(profileDetailsNumCourses, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel6.setBorder(javax.swing.BorderFactory.createTitledBorder("Grade Information"));

        profileDetailGPALabel.setText("Grade Point Average");

        profileDetailsGPA.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED));

        profileDetailsCreditsTakenLabel.setText("Credits Taken");

        profileDetailsCreditsTaken.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED));

        profileDetailsGradePointsLabel.setText("Grade Points");

        profileDetailsGradePoints.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED));

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(profileDetailGPALabel)
                    .addComponent(profileDetailsCreditsTakenLabel)
                    .addComponent(profileDetailsGradePointsLabel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(profileDetailsGPA, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(profileDetailsCreditsTaken, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(profileDetailsGradePoints, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(profileDetailGPALabel)
                    .addComponent(profileDetailsGPA, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(profileDetailsCreditsTakenLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(profileDetailsCreditsTaken, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(profileDetailsGradePointsLabel)
                    .addComponent(profileDetailsGradePoints, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jButton7.setText("Delete");
        jButton7.setEnabled(false);
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        jButton9.setText("Details");
        jButton9.setEnabled(false);

        jButton8.setText("Edit");
        jButton8.setEnabled(false);

        javax.swing.GroupLayout profilePanelLayout = new javax.swing.GroupLayout(profilePanel);
        profilePanel.setLayout(profilePanelLayout);
        profilePanelLayout.setHorizontalGroup(
            profilePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(profilePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(profilePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(profilePanelLayout.createSequentialGroup()
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(filler1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(4, 4, 4))
                    .addGroup(profilePanelLayout.createSequentialGroup()
                        .addComponent(profileComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(addProfileButton, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton8)
                        .addGap(18, 18, 18)
                        .addComponent(jButton9)
                        .addGap(18, 18, 18)
                        .addComponent(jButton7)
                        .addContainerGap())))
        );
        profilePanelLayout.setVerticalGroup(
            profilePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(profilePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(profilePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(profilePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(profileComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(addProfileButton, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(profilePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jButton7)
                        .addComponent(jButton9)
                        .addComponent(jButton8)))
                .addGroup(profilePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(profilePanelLayout.createSequentialGroup()
                        .addComponent(filler1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(profilePanelLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(profilePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(3, 3, 3))))
        );

        courseTabPane.setBorder(javax.swing.BorderFactory.createTitledBorder(""));
        courseTabPane.setToolTipText("");
        courseTabPane.setEnabled(false);
        courseTabPane.setName(""); // NOI18N
        courseTabPane.setOpaque(true);
        courseTabPane.setPreferredSize(new java.awt.Dimension(681, 454));
        courseTabPane.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                courseTabPaneStateChanged(evt);
            }
        });

        termPanel.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createEtchedBorder(), "Term", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Times New Roman", 0, 18))); // NOI18N
        termPanel.setEnabled(false);

        termComboBox.setMaximumRowCount(10);
        termComboBox.setEnabled(false);
        termComboBox.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                termComboBoxItemStateChanged(evt);
            }
        });

        addTermButton.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        addTermButton.setText("+");
        addTermButton.setAlignmentY(0.0F);
        addTermButton.setBorder(null);
        addTermButton.setEnabled(false);
        addTermButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        addTermButton.setMaximumSize(new java.awt.Dimension(24, 27));
        addTermButton.setMinimumSize(new java.awt.Dimension(24, 27));
        addTermButton.setPreferredSize(new java.awt.Dimension(24, 27));
        addTermButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addTermButtonActionPerformed(evt);
            }
        });

        jLabel1.setText("Courses in Term: ");

        termDetailsCourses.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED));

        jLabel10.setText("Credits in Term");

        termDetailsCredits.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED));

        javax.swing.GroupLayout termPanelLayout = new javax.swing.GroupLayout(termPanel);
        termPanel.setLayout(termPanelLayout);
        termPanelLayout.setHorizontalGroup(
            termPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(termPanelLayout.createSequentialGroup()
                .addGap(2, 2, 2)
                .addGroup(termPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(termPanelLayout.createSequentialGroup()
                        .addComponent(jLabel10)
                        .addGap(18, 18, 18)
                        .addComponent(termDetailsCredits, javax.swing.GroupLayout.DEFAULT_SIZE, 78, Short.MAX_VALUE))
                    .addGroup(termPanelLayout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(termDetailsCourses, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(termPanelLayout.createSequentialGroup()
                        .addComponent(termComboBox, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(addTermButton, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        termPanelLayout.setVerticalGroup(
            termPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(termPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(termPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(addTermButton, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(termComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(termPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(termDetailsCourses, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(termPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel10)
                    .addComponent(termDetailsCredits, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        fileMenu.setMnemonic('f');
        fileMenu.setText("File");

        exitMenuItem.setMnemonic('x');
        exitMenuItem.setText("Exit");
        exitMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitMenuItemActionPerformed(evt);
            }
        });
        fileMenu.add(exitMenuItem);

        menuBar.add(fileMenu);

        helpMenu.setMnemonic('h');
        helpMenu.setText("Help");

        aboutMenuItem.setMnemonic('a');
        aboutMenuItem.setText("About");
        aboutMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                aboutMenuItemActionPerformed(evt);
            }
        });
        helpMenu.add(aboutMenuItem);

        menuBar.add(helpMenu);

        setJMenuBar(menuBar);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(courseTabPane, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(profilePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(termPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(profilePanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(termPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(courseTabPane, javax.swing.GroupLayout.PREFERRED_SIZE, 600, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        courseTabPane.getAccessibleContext().setAccessibleName("termTabPane");

        bindingGroup.bind();

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void exitMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitMenuItemActionPerformed
        System.exit(0);
    }//GEN-LAST:event_exitMenuItemActionPerformed

    private void courseTabPaneStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_courseTabPaneStateChanged
        

//TODO Check for new tab and load classes
//        try{

            if ((courseTabPane.getTabCount()>1) && (addingTab==false)){
                if (courseTabPane.getTitleAt(courseTabPane.getSelectedIndex()).equals("+")){                 
                    System.out.println("tab state is resulting in adding a class because + is selected");
                    Calendar now = Calendar.getInstance();   // This gets the current date and time.
                    long timeinms=now.getTimeInMillis();
                    addCourseButtonActionPerformed();

                }
                else{
                    
                    currentCourseIndex=courseTabPane.getSelectedIndex();
                    currentTerm.setCurrentCourseIndex(currentCourseIndex);
                    currentCourse=currentTerm.getCurrentCourse();
                    tabChanged=true;
                }
            }
            else{
                //System.out.println("skipped adding tab because termTabPane has 1< tab      AddingTab="+addingTab+" TabCount="+ courseTabPane.getTabCount()+ "selected tab Name=" + courseTabPane.getTitleAt(courseTabPane.getSelectedIndex()));
            }
//        }catch(java.lang.ArrayIndexOutOfBoundsException e){
//            System.out.println("array Index Out of Bounds grades.ui 1363");
                
            {
        }    }//GEN-LAST:event_courseTabPaneStateChanged

    private void addProfileConfirmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addProfileConfirmActionPerformed
        addingProfile=true;
        
        numProfiles = profiles.size();
        
        //getting selected button and setting to a double for profile creation
        if (pointScale4.isSelected()==true){
                gradePointScaleSelectedValue=4.0;            
        }
        else if(pointScale10.isSelected()==true){
                gradePointScaleSelectedValue=10.0;            
        }
        else if(pointScale12.isSelected()==true){
                gradePointScaleSelectedValue=12.0;            
        }
        else{System.out.println("error: grade scale if statement went to else");}
        
        
        //getting selected button and setting to a string for profile creation
        if (termTypeSemester.isSelected()==true){
                termTypeSelectedValue="semester";            
        }
        else if(termTypeQuarter.isSelected()==true){
                termTypeSelectedValue="quarter";            
        }
        else if(termTypeTrimester.isSelected()==true){
                termTypeSelectedValue="trimester";            
        }
        else{System.out.println("error: termtype if statement went to else");}
        
        if (profileNameInput.getText().equals("")){
            JOptionPane.showMessageDialog(addProfile,"Please enter a Profile Name.","Please Enter A Profile Name", JOptionPane.WARNING_MESSAGE);
            
        }
        else{
            profiles.add(numProfiles,(new Profile(profileNameInput.getText(),termTypeSelectedValue,gradePointScaleSelectedValue, (numProfiles))));
            
            //Getting Names in array to add to the comboBox
            String profileNames[]=new String[profiles.size()];
            for(int i=0;i<profiles.size();i++){
                profileNames[i]=profiles.get(i).getName();
            }

             //add created profile, and all profiles to combo box and set it as selected profile
            profileComboBox.setModel(new javax.swing.DefaultComboBoxModel(profileNames));
            profileComboBox.setSelectedIndex((numProfiles));
            //TODO combine this with add to profiles array
            currentProfile=(Profile) profiles.get(numProfiles);
            //TROUBLESHOOTING
            //System.out.println("profiles.termType="+profiles[numProfiles-1].getTermType()+"  profiles.gradepointscale="+profiles[numProfiles-1].getGpaScale());
            if (firstProfile!=true){
            } else {
                //TODO see if this is redundent
                firstProfile=false;
                termComboBox.setEnabled(true);

                termPanel.setEnabled(true);
                addTermButton.setEnabled(true);
                termDetailsCourses.setEnabled(true);
                termDetailsCredits.setEnabled(true);        
                //TODO Activate all termPanel components
                //TODO add a tip to click to add term

            }
            //TODO CLEANUP
    //        //Setting up the ComboBox for a new profile
    //        String temp[]={"Add a Term>>>"};            
    //        termComboBox.setModel(new javax.swing.DefaultComboBoxModel(temp));
    //        termComboBox.setToolTipText("Click The \"+\" Button To Add a Term");
            //hiding window and reseting values
            addProfile.setVisible(false);
            updateLabels();
            addingProfile=false;
            profileNameInput.setText("");
            pointScale4.setSelected(true);
            termTypeSemester.setSelected(true);
        }
        
        
        
    }//GEN-LAST:event_addProfileConfirmActionPerformed

    private void addProfileCancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addProfileCancelActionPerformed
        addProfile.setVisible(false);
        updateLabels();
        addingProfile=false;
        profileNameInput.setText("");
        pointScale4.setSelected(true);
        termTypeSemester.setSelected(true);
    }//GEN-LAST:event_addProfileCancelActionPerformed

    private void addTermCancelButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addTermCancelButtonActionPerformed
        
        System.out.println("Addterm being hiden line 1042");
        addTerm.setVisible(false);
    }//GEN-LAST:event_addTermCancelButtonActionPerformed

    private void addTermConfirmButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addTermConfirmButtonActionPerformed
        String termSelection=" Other";
         switch(currentProfile.getTermType()){
             case "semester":
                 if (semesterFall.isSelected()==true){
                     termSelection=" Fall";
                 }
                 else if (semesterSpring.isSelected()==true){
                     termSelection=" Spring";
                 }
                 else{
                     termSelection=" Other";
                 }
             break;
             case "trimester":
                 if (trimester1.isSelected()==true){
                     termSelection=" First Trimester";
                 }
                 else if (trimester2.isSelected()==true){
                     termSelection=" Second Trimester";
                 }
                 else if (trimester3.isSelected()==true){
                     termSelection=" Third Trimester";
                 }
                 else{
                     termSelection=" Other";
                 }
             break;
             case "quarter":
                 if (quarter1.isSelected()==true){
                     termSelection=" First Quarter";
                 }
                 else if (quarter2.isSelected()==true){
                     termSelection=" Second Quarter";
                 }
                 else if (quarter3.isSelected()==true){
                     termSelection=" Third Quarter";
                 }
                 //else if (quarter4.isSelected()==true){
                 //    termSelection=" Fourth Quarter";
                 //}
                 else{
                     termSelection=" Other";
                 }
             break;
             default:
                 System.out.println(" error TermType invalid");
             break;  
        }
        //creates term name
        String name=addTermYearTextBox.getText()+termSelection;
        //adds the term to the profiles list of terms
        if (currentProfile.addTerm(name)!=true){
            JOptionPane.showMessageDialog(addTerm,"There is allready a term named: "+name+"\n Please enter a different term.","Invalid Entry", JOptionPane.WARNING_MESSAGE);
            System.out.println("term name is taken, false returned by currentProfile.addTerm(name)");
        }
        else{
           //hide form, reset form and update labels
            currentTerm=currentProfile.getCurrentTerm();
           addTerm.setVisible(false);
           System.out.println("Addterm being hiden line 1109");
             //add created Term, and all profiles to combo box and set it as selected profile
           updateTabs();
           updateLabels();
        }
    }//GEN-LAST:event_addTermConfirmButtonActionPerformed
    private void addCourseButtonActionPerformed(){
        
            System.out.println("Adding a couse on line 1559 gradesui.java");
            addCourse.setLocationRelativeTo(null);
            addCourse.setVisible(true);
            
            
            
            addingTab=true;
            
        
        
    }
    private void addCourseButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addCourseButtonActionPerformed
        addCourseButtonActionPerformed();
    }//GEN-LAST:event_addCourseButtonActionPerformed

    private void addTermButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addTermButtonActionPerformed
        
        System.out.println("Addterm being seet visible line 1029");
        
        addTerm.setLocationRelativeTo(null);
        addTermSemester.setEnabled(false);
        addTermTrimester.setEnabled(false);
        addTermQuarter.setEnabled(false);
        //This Block of code predicts what term the user wants
        Calendar now = Calendar.getInstance();   // This gets the current date and time.
        int year=now.get(Calendar.YEAR);
        int month= now.get(Calendar.MONTH);
        switch(currentProfile.getTermType()){
            case "semester":
                addTermSemester.setEnabled(true);
                if (month<=6){
                    semesterSpring.setSelected(true);
                }
                else if(month>=8){
                    semesterFall.setSelected(true);
                }
                else{
                    semesterOther.setSelected(true);
                }
            break;
            case "trimester":
                System.out.println("trimester");
                addTermTrimester.setEnabled(true);
                if (month<=4){
                    trimester2.setSelected(true);
                }
                else if(month>=9){
                    trimester1.setSelected(true);
                }
                else if (month>4 && month<=8){
                    trimester3.setSelected(true);
                }
                else{
                    trimesterOther.setSelected(true);
                }
            break;
            case "quarter":
                addTermQuarter.setEnabled(true);
                
                if (month>=9){
                    quarter1.setSelected(true);
                }
                else if(month<=3){
                    quarter2.setSelected(true);
                }
                else if(month>=3 && month<=6){
                    quarter3.setSelected(true);
                }
                else {
                    quarterOther.setSelected(true);
                }
                
            break;
            default:
                System.out.println("error TermType invalid");
            break;
       }
       addTermYearSlider.setMaximum(year+5);
       addTermYearSlider.setMinimum(year-5);
       addTermYearSlider.setValue(year);
       addTerm.setVisible(true);
        addTerm.addKeyListener
            (new KeyAdapter() {
               public void keyPressed(KeyEvent e) {
                 int key = e.getKeyCode();
                 if (key == KeyEvent.VK_ENTER) {
                    addTermConfirmButtonActionPerformed(null);
                 }
               }
            });
    }//GEN-LAST:event_addTermButtonActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        //TODO Impliment Delete Profile Button
        //        JOptionPane alert=new JOptionPane();
        //        alert.setOptionType(2);
        //        alert.setMessage("Are you Sure you want to delete "+currentProfile+"?");
        //        alert.setMessageType(3);
        //        JDialog dialog=alert.createDialog(jPanel1,"Confirm Delete Profile");
        //        dialog.setAlwaysOnTop(true);
        //        dialog.setLocationRelativeTo(null);
        //        Object selection=alert.getValue();
        //        if (selection==1){
            //            System.out.println("selction is 1");
            //        }
        //        if (selection==2){
            //            System.out.println("selction is 2");
            //        }

        //TODO: check for other profiles with trying to get a value, and catching an array out of bounds, or doesnt have value error
        //TODO: if it throws the error you know theres nothing there, if it doesnt then theres something there
    }//GEN-LAST:event_jButton7ActionPerformed

    private void addProfileButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addProfileButtonActionPerformed
        addProfile.setVisible(true);
    }//GEN-LAST:event_addProfileButtonActionPerformed

    private void profileComboBoxItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_profileComboBoxItemStateChanged
        if(addingProfile!=false){
            //TODO Troubleshooting
            System.out.println("skipped update profile combobox: adding profile in progress");
        }
        else {
            currentProfile=(Profile) profiles.get(profileComboBox.getSelectedIndex());
            currentTerm=currentProfile.getCurrentTerm();
            updateTabs();
            updateLabels();
        }
        
    }//GEN-LAST:event_profileComboBoxItemStateChanged

    private void termComboBoxItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_termComboBoxItemStateChanged
        if(addingProfile!=false){
            //TODO Troubleshooting
            System.out.println("skipped update termcombobox: adding profile in progress");
        }
        else {
            currentProfile.setCurrentTermIndex(termComboBox.getSelectedIndex());
            currentTerm=currentProfile.getCurrentTerm();
            updateTabs();
            updateLabels();
        }
        tabChanged=true;
        {
        }    }//GEN-LAST:event_termComboBoxItemStateChanged

    private void addProfileWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_addProfileWindowActivated
//        TODO fix profileconfirmbutotn looping  
//        profileNameInput.addKeyListener
//            (new KeyAdapter() {
//               public void keyPressed(KeyEvent e) {
//                 int key = e.getKeyCode();
//                 if (key == KeyEvent.VK_ENTER) {
//                    addProfileConfirmActionPerformed(null);
//                 }
//               }
//            });
        
    }//GEN-LAST:event_addProfileWindowActivated

    private void addTermYearTextBoxKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_addTermYearTextBoxKeyTyped
        
    }//GEN-LAST:event_addTermYearTextBoxKeyTyped

    private void addTermKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_addTermKeyPressed
        //TODO Fix termconfirmbutton looping
//         int key = evt.getKeyCode();
//         if (key == KeyEvent.VK_ENTER) {
//            addTermConfirmButton.doClick();
//            }
    }//GEN-LAST:event_addTermKeyPressed

    private void addCourseWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_addCourseWindowOpened
        try{
            courseNameInput.setText(currentCourse.getCourseName());
            creditTextBox.setText(""+currentCourse.getCourseCredits());
            addCourseTotalPoints.setText(""+currentCourse.getNumAssignments());
        }catch(NullPointerException e){
            System.out.println("NullPointerException line 1737 in gradesui.java: probably no course created yet");
        }

    }//GEN-LAST:event_addCourseWindowOpened

    private void addCourseWindowClosed(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_addCourseWindowClosed
        addingTab=false;
        //TODO Reset rest of addcourses components
        courseNameInput.setText("");
        creditTextBox.setText("");
        addCourseNumAssigns.setText("");
        //Change Selected Tab off of + Tab
        if (courseTabPane.getTabCount()==1){ 
        }
        else{
            //courseTabPane.setSelectedIndex(currentTerm.getCurrentCourseIndex());
        }
    }//GEN-LAST:event_addCourseWindowClosed

    private void addCourseConfirmButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addCourseConfirmButtonActionPerformed
        
        String nameInput=courseNameInput.getText();
        String creditsInput=creditTextBox.getText();
        int credits=0;
        String totalPointsInput=addCourseTotalPoints.getText();
        Double totalPoints=0.0;
        String numAssignsInput = addCourseNumAssigns.getText();
        int numAssigns=0;
        if ("".equals(nameInput)){
            //TODO add Dialog for name not input
            JOptionPane.showMessageDialog(addCourse,"Please Enter A Course Name","Please Enter A Course Name", JOptionPane.WARNING_MESSAGE);            
        }
        else if("".equals(creditsInput)){
            JOptionPane.showMessageDialog(addCourse,"Please Enter The Ammount Of Credits The Course Is Worth","Please Enter Credits", JOptionPane.WARNING_MESSAGE);            
            //NEED, otherwise ParseInt will throw an error
        }
        else {
            if (!"".equals(totalPointsInput)){
                totalPoints=Double.parseDouble(totalPointsInput);
            }
            if (!"".equals(numAssignsInput)){
                numAssigns=Integer.parseInt(numAssignsInput);
            }
            if (!"".equals(creditTextBox)){
                credits=Integer.parseInt(creditsInput);
            }
            
            currentTerm.addCourse(nameInput, credits, totalPoints, numAssigns);
            currentCourseIndex=(currentTerm.getNumCourses()-1);
            currentTerm.setCurrentCourseIndex(currentCourseIndex);
            currentCourse=currentTerm.getCurrentCourse();
            currentCourse.createCoursePanel();
            //currentCourse=(course)currentTerm.getCourseArray().get(currentCourseIndex);
            currentCourse.setName(nameInput);
            currentCourse.setCredits(Integer.parseInt(creditsInput));
            currentCourse.setTotalPoints(totalPoints);
//            currentCourse.updateTable();
            
                        
            

            
            addingTab=false;
            //TODO Reset rest of addcourses components
            courseNameInput.setText("");
            creditTextBox.setText("");
            addCourseTotalPoints.setText("");
            addCourseNumAssigns.setText("");
            tabChanged=true;
            addCourse.setVisible(false);
            updateTabs();
            updateLabels();
        }
        
    }//GEN-LAST:event_addCourseConfirmButtonActionPerformed

    private void addCourseCancelButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addCourseCancelButtonActionPerformed
        addCourse.setVisible(false);
        addingTab=false;
        //TODO Reset rest of addcourses components
        courseNameInput.setText("");
        creditTextBox.setText("");
        addCourseNumAssigns.setText("");
        //Change Selected Tab off of + Tab
        if (courseTabPane.getTabCount()==1){ 
        }
        else{
            courseTabPane.setSelectedIndex(courseTabPane.getSelectedIndex()-1);
        }
            
    }//GEN-LAST:event_addCourseCancelButtonActionPerformed

    private void addCourseNumAssignsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addCourseNumAssignsActionPerformed

    }//GEN-LAST:event_addCourseNumAssignsActionPerformed

    private void addCourseNumAssignsFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_addCourseNumAssignsFocusLost
        //TODO REMOVE--Was Being Used For Adding Assignments in AddCourse Window
//        if (addCourseNumAssigns.getText().equals("")){}
//        else {
//            currentCourse.setNumAssigns(Integer.parseInt(addCourseNumAssigns.getText()));
//            
//        }        
    }//GEN-LAST:event_addCourseNumAssignsFocusLost

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void aboutMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_aboutMenuItemActionPerformed
        aboutWindow.setBounds(0, 0, 500, 500);
        aboutWindow.setVisible(true);
        aboutWindow.setLocationRelativeTo(null);
    }//GEN-LAST:event_aboutMenuItemActionPerformed
    public void showAddCourse(){
        addCourse.setLocationRelativeTo(null);
        addCourse.setVisible(true);
    }
    public JDialog getAddCourse(){
        return addCourse;
    }
    public void updateTabs(){
        addingTab=true;
        if (courseTabPane.getTabCount()>0){
            courseTabPane.removeAll();
        }
        currentTerm=currentProfile.getCurrentTerm();
        
        //try{
            
            ArrayList <course> tempCourseArray=currentTerm.getCourseArray();
            for (int i=0;i<tempCourseArray.size();i++){
                System.out.print("course name "+ i + " is: " + (tempCourseArray.get(i)).getName());
                System.out.println("cell 3 in row 0 is: " + (tempCourseArray.get(i)).getAssignmentTable().getValueAt(0, 2));
            }
            for (int i=0;i<tempCourseArray.size();i++){
                courseTabPane.insertTab((tempCourseArray.get(i)).getName(), null, (tempCourseArray.get(i)).getCoursePanel() , "Click The + Tab To Add A New Course", i);
                System.out.println("adding tab course:"+ (tempCourseArray.get(i)).getName() + "in term " + currentTerm.getName());
                //((course) currentTerm.getCourseArray().get(i)).updateLabels();
            }
        //}catch(NullPointerException e){
        //    System.out.println("nullpointerexception in update tabs Gradesui 1850");
        //}
    
        courseTabPane.add("+", addCourseButton);
        
    }
    public void updateLabels(){
        
        if (!firstProfile){
            String gpaType=Double.toString(currentProfile.getProfileGpaScale());
            String gpa=Double.toString(currentProfile.getProfileGPA());
            String numCourses=Integer.toString(currentProfile.getProfileNumCourses());
            String credits=Integer.toString(currentProfile.getProfileCredits());
            String gradePoints=Integer.toString(currentProfile.getProfileGradePoints());
            profileDetailsGradePointScale.setText(gpaType);
            profileDetailsGPA.setText(gpa);
            profileDetailsNumCourses.setText(numCourses);
            profileDetailsCreditsTaken.setText(credits);
            profileDetailsGradePoints.setText(gradePoints);
            profileDetailsTermType.setText(currentProfile.getTermType());
            
            //Setting TermComboBox contents and selecting the current term
            termNames=currentProfile.getTermNames();
            numTerms=termNames.size();
            addingTab=true;
            if (numTerms>0){
                
                currentTerm=currentProfile.getCurrentTerm();
                addingProfile=true;
                termComboBox.setModel(new javax.swing.DefaultComboBoxModel(termNames.toArray()));
                termComboBox.setSelectedIndex(currentProfile.getCurrentTermIndex());

                //Term Labels updates
                ArrayList<course> courses=currentTerm.getCourseArray();
                int numCoursesInTerm=courses.size();

                //Update Term Detail Labels
                termDetailsCredits.setEnabled(true);
                termDetailsCourses.setEnabled(true);
                termDetailsCredits.setText(Integer.toString(currentTerm.getCredits()));
                termDetailsCourses.setText(Integer.toString(numCoursesInTerm));
                addingProfile=false;
                courseTabPane.setEnabled(true);
                

                //TODO Optimize this block of Code
                //courseTabPane.removeAll();
                if (numCoursesInTerm!=0){
                   

                   
                                      
                   
                }
                //end of updating Tabs If Statement
            }
            //If there are no classes in the term
            else{
                //Setting up the ComboBox for a new profile
                termDetailsCredits.setEnabled(false);
                termDetailsCredits.setText("");
                termDetailsCourses.setEnabled(false);
                termDetailsCourses.setText("");
                
                String temp[]={"Add a Term>>>"};            
                termComboBox.setModel(new javax.swing.DefaultComboBoxModel(temp));
                termComboBox.setToolTipText("Click The \"+\" Button To Add a Term");

                courseTabPane.setEnabled(false);
                courseTabPane.removeAll();

            }
            tabChanged=false;
            addingTab=false;
        }
    }
   
    
    class MyDocumentFilter extends DocumentFilter{   
        @Override
        public void insertString(FilterBypass fb, int off
                            , String str, AttributeSet attr) 
                                    throws BadLocationException 
        {
            // remove non-digits
            fb.insertString(off, str.replaceAll("\\D++", ""), attr);
        } 
        @Override
        public void replace(FilterBypass fb, int off
                , int len, String str, AttributeSet attr) 
                                throws BadLocationException 
        {
            // remove non-digits
            fb.replace(off, len, str.replaceAll("\\D++", ""), attr);
        }
    }
    
    
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(gradesui.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new gradesui().setVisible(true);
            }
        });
        
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup AddTermTrimesterButton;
    private javax.swing.JMenuItem aboutMenuItem;
    private javax.swing.JFrame aboutWindow;
    private javax.swing.JDialog addCourse;
    private javax.swing.JButton addCourseButton;
    private javax.swing.JButton addCourseCancelButton;
    private javax.swing.JButton addCourseConfirmButton;
    private javax.swing.JFormattedTextField addCourseNumAssigns;
    private javax.swing.JFormattedTextField addCourseTotalPoints;
    private javax.swing.JDialog addProfile;
    private javax.swing.JButton addProfileButton;
    private javax.swing.JButton addProfileCancel;
    private javax.swing.JButton addProfileConfirm;
    private javax.swing.ButtonGroup addProfileGradePointScale;
    private javax.swing.ButtonGroup addProfileTermType;
    private javax.swing.JDialog addTerm;
    private javax.swing.JButton addTermButton;
    private javax.swing.JButton addTermCancelButton;
    private javax.swing.JButton addTermConfirmButton;
    private javax.swing.JPanel addTermQuarter;
    private javax.swing.ButtonGroup addTermQuarterButton;
    private javax.swing.JPanel addTermSemester;
    private javax.swing.ButtonGroup addTermSemesterButton;
    private javax.swing.JPanel addTermTrimester;
    private javax.swing.JSlider addTermYearSlider;
    private javax.swing.JFormattedTextField addTermYearTextBox;
    private javax.swing.JList course;
    private javax.swing.JTable courseGradeTable1;
    private javax.swing.JFormattedTextField courseNameInput;
    private javax.swing.JTabbedPane courseTabPane;
    private javax.swing.JTextField creditTextBox;
    private javax.swing.JPanel demo;
    private javax.swing.JPanel demo2;
    private javax.swing.JMenuItem exitMenuItem;
    private javax.swing.JMenu fileMenu;
    private javax.swing.Box.Filler filler1;
    private javax.swing.JMenu helpMenu;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JDialog jDialog1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JList jList1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JMenuBar menuBar;
    private javax.swing.JRadioButton pointScale10;
    private javax.swing.JRadioButton pointScale12;
    private javax.swing.JRadioButton pointScale4;
    private javax.swing.JComboBox profileComboBox;
    private javax.swing.JLabel profileDetailGPALabel;
    private javax.swing.JLabel profileDetailsCreditsTaken;
    private javax.swing.JLabel profileDetailsCreditsTakenLabel;
    private javax.swing.JLabel profileDetailsGPA;
    private javax.swing.JLabel profileDetailsGradePointScale;
    private javax.swing.JLabel profileDetailsGradePointScaleLabel;
    private javax.swing.JLabel profileDetailsGradePoints;
    private javax.swing.JLabel profileDetailsGradePointsLabel;
    private javax.swing.JLabel profileDetailsNumCourses;
    private javax.swing.JLabel profileDetailsNumCoursesLabel;
    private javax.swing.JLabel profileDetailsTermType;
    private javax.swing.JLabel profileDetailsTermTypeLabel;
    private javax.swing.JFormattedTextField profileNameInput;
    private javax.swing.JPanel profilePanel;
    private javax.swing.JRadioButton quarter1;
    private javax.swing.JRadioButton quarter2;
    private javax.swing.JRadioButton quarter3;
    private javax.swing.JRadioButton quarterOther;
    private javax.swing.JRadioButton semesterFall;
    private javax.swing.JRadioButton semesterOther;
    private javax.swing.JRadioButton semesterSpring;
    private javax.swing.JComboBox termComboBox;
    private javax.swing.JLabel termDetailsCourses;
    private javax.swing.JLabel termDetailsCredits;
    private javax.swing.JPanel termPanel;
    private javax.swing.JRadioButton termTypeQuarter;
    private javax.swing.JRadioButton termTypeSemester;
    private javax.swing.JRadioButton termTypeTrimester;
    private javax.swing.JRadioButton trimester1;
    private javax.swing.JRadioButton trimester2;
    private javax.swing.JRadioButton trimester3;
    private javax.swing.JRadioButton trimesterOther;
    private javax.swing.JFrame troubleshoot;
    private org.jdesktop.beansbinding.BindingGroup bindingGroup;
    // End of variables declaration//GEN-END:variables
}
