/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package grades;

import java.util.ArrayList;
import javax.swing.JTable;

/**
 *
 * @author Nicholas
 */
public class term extends Profile{
    String name;
    private int numCourses, credits;
    private ArrayList<course> courses;
    Profile profile;
    public term(String name, Profile profile){
        super(profile.getName(), profile.getTermType(),profile.getGpaScale(),profile.getIndex());
        this.profile=profile;
        this.name=name;
        this.credits=0;
        this.numCourses=0;
        courses=new ArrayList();
    }
    
    public Profile getProfile(){
        return profile;
    }
    public String getName(){
        return name;
    }
    public void setName(String name){
        this.name=name;
    }
    public ArrayList getCourseArray(){
        return courses;
    }
    public int getCourseNum(){
        return numCourses;
    }
    public course getCourse(int i){
        return courses.get(i);
    }
    //TODO see if needed for loading
//    public void addCourse(String name, int credits, JTable table, Double totalPoints){
//        numCourses++;
//        courses.add(new course(name, credits, table, totalPoints));
//        this.credits=this.credits+credits;
//        
//    }
    public void addCourse(){
        
        courses.add(new course(this));
        courses.get(courses.size()-1).createCoursePanel(this);
        
        System.out.println("term addcourse(table,profile)");
        numCourses++;

    }
    public int getCredits(){
        return credits;
    }
    public int getNumCourses(){
        return numCourses;
    }
 
    
}
