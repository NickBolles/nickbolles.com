/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package grades;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.text.DecimalFormat;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

/**
 *
 * @author Nicholas
 */
public class course extends term{
    private String name;
    private int credits, numAssignments, gradePoints;
    private Double totalPoints, scoredPoints, gradePercent;
    public JTable assignmentTable, courseGradeTable;
    private JPanel tabPanel,jPanel9;
    private JLabel jLabel17, jLabel19,jLabel21,jLabel23,jLabel28,jLabel30,jLabel29,courseDetailsGradePoints,courseDetailsGradeLetter,courseDetailsGradePercent,jLabel27;
    private JButton jButton1,jButton4, jButton5,jButton6,jButton10,jButton11;
    private JScrollPane jScrollPane1,courseTableScrollPane;
    private coursePanel coursePanel;

    course(term term){
        super(term.getName(), term.getProfile());
        assignmentTable=new JTable(new MyTableModel());
        assignmentTable.setValueAt("yes it worked", 0, 0);
        numAssignments=0;
        totalPoints=0.0;
        scoredPoints=0.0;
        gradePoints=0; 
        gradePercent=0.0;
        credits=0;
        //TODO look for way to just "go up" and get the data       
    }
    
//    course(String name, int credits, JTable table, Double totalPoints, Profile currentProfile){
//        super(term.getName(), term.getProfile());
//        this.name=name;
//        this.credits=credits;
//        this.assignmentTable=table;
//        this.totalPoints=totalPoints;
//        this.currentProfile=currentProfile;
//        numAssignments=0;
//        scoredPoints=0.0;
//        gradePoints=0.0; 
//        gradePercent=0.0;
//       
//        courseTableScrollPane.setViewportView(assignmentTable);     
//
//    }
    
    public void createCoursePanel(term term){
        coursePanel=new coursePanel(term);
    }
    public void repaint(){
        coursePanel.repaintTable();
    }
        
    public String getName(){
        return name;
    }
    public void setName(String name){
        this.name=name;
    }

    public JTable getAssignmentTable(){
        return assignmentTable;
    }
    public void setAssignmentTable(JTable table){
        this.assignmentTable=table;
    }
    
    public int getNumAssignments(){
        numAssignments=assignmentTable.getRowCount();
        return numAssignments;
    }
    public Double getScoredPoints(){
        TableModel model=assignmentTable.getModel();
        int numRows=model.getRowCount()-1;
        scoredPoints=0.0;
        for(int i=0;i<numRows;i++){
            try{
                scoredPoints=scoredPoints+(Double)model.getValueAt(i,1);
            }catch(NullPointerException e){
                System.out.println("NullPointerException when getting Scored Points at index (2,"+i+")");
            }
        }
        return scoredPoints;
    }
    public Double getTotalPoints(){
        TableModel model=assignmentTable.getModel();
        int numRows=model.getRowCount()-1;
        totalPoints=0.0;
        for(int i=0;i<numRows;i++){
            try{
                Double temp=(Double)model.getValueAt(i,2);
                totalPoints=totalPoints+temp;
            }catch(NullPointerException e){
                System.out.println("NullPointerException when getting Total Points at index (3,"+i+")");
            }        }
        return totalPoints;
    }
    public void setTotalPoints(Double totalPoints){
        this.totalPoints=totalPoints;
    }
    public int getCredits(){
        return credits;
    }
    public void setCredits(int credits){
        this.credits=credits;
    }
    public void setGradePoints(int grade){
        this.gradePoints=this.credits*grade;
    }
    public int getGradePoints(){
        return gradePoints;
    }
    public JPanel getCoursePanel(){
        repaint();
        coursePanel.troubleshoot();
        tabPanel=coursePanel.getPanel();
         return tabPanel;
    }
    public void setNumAssigns(int input){
            int numRows=assignmentTable.getRowCount();
            int diff=0;
            MyTableModel model=(MyTableModel)assignmentTable.getModel();
            if (numRows<input){
                //figure out how many rows to add
                diff=(input-numRows);
                for (int i=0; i<diff;i++){
                    boolean addingRows=true;
                    model.addRow(new Object[]{"",0.0,0.0,0.0,0.0});
                }
                System.out.println("DONE updating model with new rows");
                //Problem is in update rows!!!!
                model.updateRows();
            }
            else if(numRows>input){
                //figure out how many rows to delete
                diff=(numRows-input);
                for (int i=0; i<diff ;i++){
                    ((MyTableModel) assignmentTable.getModel()).removeRow(numRows-(i+1));
                }
                model.updateRows();
            }
            numAssignments=input;
    }
    public void updateTable(){
        ((MyTableModel) assignmentTable.getModel()).tableDataChanged();
    }
    
    
    public void updateLabels(){
        System.out.println("course update labels"+name);
        //TODO Update Labels codes
        coursePanel.updateLabels(name,credits,numAssignments,totalPoints,scoredPoints);
       DecimalFormat df = new DecimalFormat("###.##");
       gradePercent=(scoredPoints*100)/totalPoints;
       String tempGradePercent=df.format(gradePercent);
       coursePanel.setCourseDetailsGradePercent(tempGradePercent);
       Double[] gradeVals={0.9,0.8,0.7,0.6,0.5};
       if(gradePercent>=90){
           coursePanel.setCourseDetailsGradeLetter("A");
           setGradePoints(4);

       }
       else if(gradePercent<90 && gradePercent>=80){
           coursePanel.setCourseDetailsGradeLetter("B");
           setGradePoints(3);
       }
       else if(gradePercent<80 && gradePercent>=70){
           coursePanel.setCourseDetailsGradeLetter("C");
           setGradePoints(2);
       }
       else if(gradePercent<70 && gradePercent>=60){
           coursePanel.setCourseDetailsGradeLetter("D");
           setGradePoints(1);
       }
       else if(gradePercent<60){
           coursePanel.setCourseDetailsGradeLetter("F");
           setGradePoints(0);
       }
       else{
           coursePanel.setCourseDetailsGradeLetter("N/A");
           setGradePoints(0);
       }
       double gpaChange[]=new double[5];
       coursePanel.setCourseDetailsGradePoints(""+ gradePoints);

        //TODO TROUBLESHOOTING

       //calculating GPA impact. and setting the Table
       //Figure out how to get profile, because Course is part of a profi
       int profGradePoints=getProfileGradePoints();
       int profCredits=getProfileCredits();
       double currentCredits=credits+profCredits;
       if ((currentCredits)==0){
            gpaChange[0]=(profGradePoints+(4.0*credits))/(currentCredits);
            gpaChange[1]=(profGradePoints+(3.0*credits))/(currentCredits);
            gpaChange[2]=(profGradePoints+(2.0*credits))/(currentCredits);
            gpaChange[3]=(profGradePoints+(1.0*credits))/(currentCredits);
            gpaChange[4]=(profGradePoints/(currentCredits));
            coursePanel.setGPAChange(gpaChange);
            
       }
       else{
           for (int i=0;i<5;i++){
            gradeVals[i]=0.0;
            }
       }

        for (int i=0;i<5;i++){
            coursePanel.setPointsNeeded(i,totalPoints*gradeVals[i]);
       }
        
        
        //Update Table Values
        MyTableModel model=(MyTableModel)assignmentTable.getModel();
        int numRows=model.data.get(2).size();
        for(int i=0;i<numRows;i++){
           ArrayList<Double> scores=model.scores;
           ArrayList<Double> points=model.points;
           Double newValue=0.0;
           try{
               Double tempScore=scores.get(i);
               Double tempPoints= points.get(i);
               newValue=(tempScore*100)/tempPoints;
               
           //Catch a nullpointer in case not all of the information is there yet
           }catch(NullPointerException error){
               System.out.println("nullpointer exception on line 1842");
           }
           model.gpaImpact.set(i, (newValue));
                        }
//        jPanel9.repaint();
//       tabPanel.repaint();
    }
    
    
    
    
    
    
    
    class  MyTableModel extends AbstractTableModel {
        private final String[] columnNames = {"Assignment Name", "Score","Points","weight","Percentage"};
        
        private ArrayList<String> assignmentNames=new ArrayList<String>() {{
            add(new String ("HI"));
        }};
        
        private ArrayList<Double> scores=new ArrayList<Double>() {{
            add(new Double (0.0));
        }};
        private ArrayList<Double> points=new ArrayList<Double>() {{
            add(new Double (0.0));
        }};
        private ArrayList<Double> weight=new ArrayList<Double>() {{
            add(new Double (0.0));
        }};
        private ArrayList<Double> gpaImpact=new ArrayList<Double>() {{
            add(new Double (0.0));
        }};
        private ArrayList<ArrayList> data=new ArrayList<ArrayList>() {{
                                                add(assignmentNames);
                                                add(scores);
                                                add(points);
                                                add(weight);
                                                add(gpaImpact);
                                            }};
        
        
        Class[] types = new Class [] {
                        java.lang.String.class, java.lang.Double.class, java.lang.Double.class, java.lang.Double.class, java.lang.Double.class
                    };

        
        

        public int getColumnCount() {
            return columnNames.length;
        }

        public int getRowCount() {
            int rowCount=0;
            try {
                rowCount=data.get(0).size();
            }catch(NullPointerException e){
                System.out.println("nullpointerexception in get row count in course");
                rowCount=0;
            }
            
            return rowCount;
        }

        public String getColumnName(int col) {
            return columnNames[col];
        }

        public Object getValueAt(int row, int col) {
            return data.get(col).get(row);
        }

        public Class getColumnClass(int c) {
            Class classType=Double.class;
            if (c==0){
                classType=String.class;
            }
            return classType;
        }
        
        public void updateRows(){
            System.out.println("UpdateRows() in model");
            fireTableRowsInserted(0, assignmentTable.getModel().getRowCount()-1);   
        }
        
        public void tableDataChanged(){
            this.fireTableDataChanged();
        }
        
        public boolean isCellEditable(int row, int col) {
            //Note that the data/cell address is constant,
            //no matter where the cell appears onscreen.
            if (col < 4) {
                return true;
            } else {
                return false;
            }
        }

        /*
         * Don't need to implement this method unless your table's
         * data can change.
         */
        public void setValueAt(Object value, int row, int col) {
            data.get(col).set(row, value);
            fireTableCellUpdated(row, col);
            if (col==1||col==2){
                  Double newValue=0.0;
                    try{
                       Double tempScore=scores.get(row);
                       Double tempPoints= points.get(row);
                       newValue=(tempScore*100)/tempPoints;
                       this.setValueAt(newValue, row, 4);
                   }catch(NullPointerException error){
                       System.out.println("nullpointer exception on line 358");
                   }catch(java.lang.IndexOutOfBoundsException IOBE){
                       System.out.println("IndexOutOfBoundsException on line 360 in course, probably adding a row");
                   }
                    
                   
                   this.fireTableRowsUpdated(row, row);
                   
            }
            try{
                updateLabels();
                
            }catch(NullPointerException e){
                System.out.println("nullpointer exception for current Course");
            }catch(java.lang.IndexOutOfBoundsException IOBE){
                System.out.println("IndexOutOfBoundsException on line 374 in course, probably adding a row");                
            }
            this.fireTableCellUpdated(row, col);
            

        }
        public void addRow(Object [] rowData){
            int columns=data.size();            
            for (int d=0;d<columns;d++){
                data.get(d).add(rowData[d]);
                
                setValueAt(rowData[d],(data.get(d).size()-1),d);
            }
            System.out.println("done adding Row");
        }
        public void removeRow(int rowIndex){
            int columns=data.size();            
            for (int d=0;d<columns;d++){
                data.get(d).remove(rowIndex);
            }
            fireTableRowsDeleted(rowIndex,rowIndex);
        }
        
    }
    
}
