/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package grades;

import java.awt.event.ActionEvent;
import java.text.DecimalFormat;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.TableModel;

/**
 *
 * @author Nicholas
 */
public class course {
    private String name;
    private int credits, numAssignments;
    private Double totalPoints=0.0, scoredPoints=0.0, gradePoints=0.0,gradePercent=0.0;
    private JTable assignmentTable, courseGradeTable;
    private JPanel tabPanel,jPanel9;
    private JLabel jLabel17, courseDetailsName, jLabel19,courseDetailsTotalPoints,jLabel21,courseDetailsScoredPoints,jLabel23,courseDetailsCredits,jLabel28,courseDetailsGradePoints,jLabel30,courseDetailsNumAssigns,jLabel29,courseDetailsGradeLetter,courseDetailsGradePercent,jLabel27,courseDetailsPointsPer;
    private JButton jButton1,jButton4, jButton5,jButton6,jButton10,jButton11;
    private JScrollPane jScrollPane1,courseTableScrollPane;
    private Profile currentProfile;
    
    course(String name, int credits, JTable table, Double totalPoints, Profile currentProfile){
        this.name=name;
        this.credits=credits;
        this.assignmentTable=table;
        this.totalPoints=totalPoints;
        this.currentProfile=currentProfile;
        numAssignments=0;
        scoredPoints=0.0;
        gradePoints=0.0; 
        gradePercent=0.0;
       tabPanel = new javax.swing.JPanel();
        jPanel9 = new javax.swing.JPanel();
        jLabel17 = new javax.swing.JLabel();
        courseDetailsName = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        courseDetailsTotalPoints = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        courseDetailsScoredPoints = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        courseDetailsCredits = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        courseDetailsGradePoints = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        courseDetailsNumAssigns = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jLabel29 = new javax.swing.JLabel();
        courseDetailsGradeLetter = new javax.swing.JLabel();
        jButton6 = new javax.swing.JButton();
        courseDetailsGradePercent = new javax.swing.JLabel();
        jButton10 = new javax.swing.JButton();
        jLabel27 = new javax.swing.JLabel();
        courseDetailsPointsPer = new javax.swing.JLabel();
        jButton11 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        courseGradeTable = new javax.swing.JTable();
        courseTableScrollPane = new javax.swing.JScrollPane();
        tabPanel.setPreferredSize(new java.awt.Dimension(681, 454));
        createPanel();
        courseTableScrollPane.setViewportView(assignmentTable);     

    }
    private void createPanel(){
        

        jPanel9.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Course Details", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Times New Roman", 1, 14))); // NOI18N

        jLabel17.setText("Course Name: ");

        courseDetailsName.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));

        jLabel19.setText("Total Possible Points:");

        courseDetailsTotalPoints.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        courseDetailsTotalPoints.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        jLabel21.setText("Points Earned");

        courseDetailsScoredPoints.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        courseDetailsScoredPoints.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        jLabel23.setText("Credits");

        courseDetailsCredits.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED));

        jLabel28.setText("Current Grade Points: ");

        courseDetailsGradePoints.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        courseDetailsGradePoints.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        jLabel30.setText("Number Of Assignments");

        courseDetailsNumAssigns.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        courseDetailsNumAssigns.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        jButton1.setText("Details");
        jButton1.setEnabled(false);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }

            private void jButton1ActionPerformed(ActionEvent evt) {
                throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }
        });

        jButton4.setText("Delete");
        jButton4.setEnabled(false);
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }

            private void jButton4ActionPerformed(ActionEvent evt) {
                throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }
        });

        jButton5.setText("Add Assign.");
        jButton5.setToolTipText("");
        jButton5.setEnabled(false);

        jLabel29.setText("Current Grade:");

        courseDetailsGradeLetter.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        courseDetailsGradeLetter.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        jButton6.setText("Edit");
        jButton6.setEnabled(false);
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }

            private void jButton6ActionPerformed(ActionEvent evt) {
                throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }
        });

        courseDetailsGradePercent.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        courseDetailsGradePercent.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        jButton10.setText("Del Assign.");
        jButton10.setToolTipText("");
        jButton10.setEnabled(false);

        jLabel27.setText("Points per %");

        courseDetailsPointsPer.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        courseDetailsPointsPer.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        jButton11.setText("Finalize");
        jButton11.setEnabled(false);
        jButton11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton11ActionPerformed(evt);
            }

            private void jButton11ActionPerformed(ActionEvent evt) {
                throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }
        });

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel9Layout.createSequentialGroup()
                                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel17)
                                    .addComponent(jLabel23))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(courseDetailsCredits, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(courseDetailsName, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel9Layout.createSequentialGroup()
                                .addComponent(jLabel30)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(courseDetailsNumAssigns, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton10)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addComponent(jLabel28)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(courseDetailsGradePoints, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addComponent(jLabel29)
                        .addGap(18, 18, 18)
                        .addComponent(courseDetailsGradeLetter, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(courseDetailsGradePercent, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addComponent(jLabel27)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(courseDetailsPointsPer, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel19)
                            .addComponent(jLabel21))
                        .addGap(13, 13, 13)
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(courseDetailsTotalPoints, javax.swing.GroupLayout.DEFAULT_SIZE, 46, Short.MAX_VALUE)
                            .addComponent(courseDetailsScoredPoints, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(6, 6, 6))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel17)
                            .addComponent(courseDetailsName, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel23)
                            .addComponent(courseDetailsCredits, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(courseDetailsTotalPoints, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel19))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(courseDetailsScoredPoints, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel21))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(courseDetailsNumAssigns, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel30)
                    .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(courseDetailsPointsPer, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel27)))
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton5)
                            .addComponent(jButton10))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel9Layout.createSequentialGroup()
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel9Layout.createSequentialGroup()
                                .addGap(0, 0, 0)
                                .addComponent(jLabel29)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel9Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(courseDetailsGradeLetter, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(courseDetailsGradePercent, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(6, 6, 6)))
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel28)
                            .addComponent(courseDetailsGradePoints, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)))))
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGap(3, 3, 3)
                .addComponent(jButton1)
                .addGap(0, 0, 0)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton4, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel9Layout.createSequentialGroup()
                        .addComponent(jButton6)
                        .addGap(23, 23, 23)))
                .addGap(0, 0, 0)
                .addComponent(jButton11))
        );

        courseGradeTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {"A", null, null},
                {"B", null, null},
                {"C", null, null},
                {"D", null, null},
                {"F", null, null}
            },
            new String [] {
                "Grade", "Points Needed", "GPA Impact"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.Double.class, java.lang.Double.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        courseGradeTable.getColumnModel().getColumn(0).setPreferredWidth(50);
        courseGradeTable.getColumnModel().getColumn(1).setPreferredWidth(95);
        courseGradeTable.getColumnModel().getColumn(2).setPreferredWidth(75);
        jScrollPane1.setViewportView(courseGradeTable);

        javax.swing.GroupLayout tabPanelLayout = new javax.swing.GroupLayout(tabPanel);
        tabPanel.setLayout(tabPanelLayout);
        tabPanelLayout.setHorizontalGroup(
            tabPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(tabPanelLayout.createSequentialGroup()
                .addGap(2, 2, 2)
                .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 234, Short.MAX_VALUE))
            .addComponent(courseTableScrollPane)
        );
        tabPanelLayout.setVerticalGroup(
            tabPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(tabPanelLayout.createSequentialGroup()
                .addGroup(tabPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(courseTableScrollPane, javax.swing.GroupLayout.DEFAULT_SIZE, 327, Short.MAX_VALUE))
        );
        courseTableScrollPane.setViewportView(assignmentTable);
    }
    public String getName(){
        return name;
    }
    public JTable getAssignmentTable(){
        return assignmentTable;
    }
    
    public int getNumAssignments(){
        numAssignments=assignmentTable.getRowCount();
        return numAssignments;
    }
    public Double getScoredPoints(){
        TableModel model=assignmentTable.getModel();
        int numRows=model.getRowCount()-1;
        scoredPoints=0.0;
        for(int i=0;i<numRows;i++){
            try{
                scoredPoints=scoredPoints+(Double)model.getValueAt(i,1);
            }catch(NullPointerException e){
                System.out.println("NullPointerException when getting Scored Points at index (2,"+i+")");
            }
        }
        return scoredPoints;
    }
    public Double getTotalPoints(){
        TableModel model=assignmentTable.getModel();
        int numRows=model.getRowCount()-1;
        totalPoints=0.0;
        for(int i=0;i<numRows;i++){
            try{
                Double temp=(Double)model.getValueAt(i,2);
                totalPoints=totalPoints+temp;
            }catch(NullPointerException e){
                System.out.println("NullPointerException when getting Total Points at index (3,"+i+")");
            }        }
        return totalPoints;
    }
    public void setTotalPoints(Double totalPoints){
        this.totalPoints=totalPoints;
    }
    public int getCredits(){
        return credits;
    }
    public void setCredits(int credits){
        this.credits=credits;
    }
    public void setGradePoints(Double grade){
        this.gradePoints=this.credits*grade;
    }
    public Double getGradePoints(){
        return gradePoints;
    }
    public JPanel getCoursePanel(){
        return tabPanel;
    }
    public void updateLabels(){
        System.out.println("course update labels"+name);
        //TODO Update Labels codes
       this.courseDetailsCredits.setText(Integer.toString(credits));
       this.courseDetailsNumAssigns.setText(Integer.toString(numAssignments));
       this.courseDetailsTotalPoints.setText(Double.toString(totalPoints));
       this.courseDetailsScoredPoints.setText(Double.toString(scoredPoints));
       this.courseDetailsPointsPer.setText(""+ (totalPoints*.1));
       DecimalFormat df = new DecimalFormat("###.##");
       gradePercent=(scoredPoints*100)/totalPoints;
       String tempGradePercent=df.format(gradePercent);
       this.courseDetailsGradePercent.setText(tempGradePercent);
       Double[] gradeVals={0.9,0.8,0.7,0.6,0.5};
       if(gradePercent>=90){
           this.courseDetailsGradeLetter.setText("A");
           setGradePoints(4.0);

       }
       else if(gradePercent<90 && gradePercent>=80){
           this.courseDetailsGradeLetter.setText("B");
           setGradePoints(3.0);
       }
       else if(gradePercent<80 && gradePercent>=70){
           this.courseDetailsGradeLetter.setText("C");
           setGradePoints(2.0);
       }
       else if(gradePercent<70 && gradePercent>=60){
           courseDetailsGradeLetter.setText("D");
           setGradePoints(1.0);
       }
       else if(gradePercent<60){
           this.courseDetailsGradeLetter.setText("F");
           setGradePoints(0.0);
       }
       else{
           this.courseDetailsGradeLetter.setText("N/A");
           setGradePoints(0.0);
       }
       double gpaChange[]=new double[5];
       this.courseDetailsGradePoints.setText(""+ gradePoints);


       //calculating GPA impact. and setting the Table
       //Figure out how to get profile, because Course is part of a profi
       int profGradePoints=currentProfile.getGradePoints();
       int profCredits=currentProfile.getCredits();
       double currentCredits=credits+profCredits;
       if ((currentCredits)==0){
            gpaChange[0]=(profGradePoints+(4.0*credits))/(currentCredits);
            gpaChange[1]=(profGradePoints+(3.0*credits))/(currentCredits);
            gpaChange[2]=(profGradePoints+(2.0*credits))/(currentCredits);
            gpaChange[3]=(profGradePoints+(1.0*credits))/(currentCredits);
            gpaChange[4]=(profGradePoints/(currentCredits));
       }
       else{
           for (int i=0;i<5;i++){
            gradeVals[i]=0.0;
            }
       }

        for (int i=0;i<5;i++){
            this.courseGradeTable.setValueAt(totalPoints*gradeVals[i],i, 1);


            this.courseGradeTable.setValueAt(gpaChange[i],i, 2);
       }
        jPanel9.repaint();
       tabPanel.repaint();
    }
    
}
