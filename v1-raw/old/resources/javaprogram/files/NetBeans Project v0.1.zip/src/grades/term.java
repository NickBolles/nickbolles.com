/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package grades;

import java.util.ArrayList;
import javax.swing.JTable;

/**
 *
 * @author Nicholas
 */
public class term {
    String name;
    private int numCourses, credits;
    private ArrayList<course> courses;
    public term(String name){
        this.name=name;
        this.credits=0;
        this.numCourses=0;
        courses=new ArrayList();
    }
    
    public String getName(){
        return name;
    }
    public void setName(String name){
        this.name=name;
    }
    public ArrayList getCourseArray(){
        return courses;
    }
    public course getCourse(int i){
        return courses.get(i);
    }
    public void addCourse(String name, int credits, JTable table, Double totalPoints, Profile currentProfile){
        numCourses++;
        courses.add(new course(name, credits, table, totalPoints, currentProfile));
        this.credits=this.credits+credits;
        
    }
    public int getCredits(){
        return credits;
    }
    public int getNumCourses(){
        return numCourses;
    }
 
    
}
